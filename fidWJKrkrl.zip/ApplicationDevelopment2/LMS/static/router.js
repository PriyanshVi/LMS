import home from './components/home.js';
import librarian_login from './components/librarian_login.js';
import library_dashboard from './components/library_dashboard.js';
import login from './components/login.js';
import manage_books from './components/manage_books.js';
import manage_sections from './components/manage_sections.js';
import user_dashboard from './components/user_dashboard.js';
import user_register from './components/user_register.js';

Vue.use(VueRouter);

const routes = [
    { path: '/', component: home },
    { path: '/login', component: login, name: 'login' },
    { path: '/librarian_login', component: librarian_login },
    { path: '/user_register', component: user_register },
    { path: '/library_dashboard', component: library_dashboard },
    { path: '/user_dashboard', component: user_dashboard },
    { path: '/manage_books', component: manage_books },
    { path: '/manage_sections', component: manage_sections },
];

export default new VueRouter({
    routes,
});