export default {
    template:
    `<div class="container" style="margin-top: 5px; align-items: center; display: flex; flex-direction: column; font-family: 'Times New Roman', Times, serif">
      <h2>Application Metrics</h2>
      <div class="container">
        <div class="row">
          <div class="col-4">
            <div class="card">
              <div class="card-body">
                <h2 class="card-title">Total Users</h2>
                <h3 class="card-text">{{ total_users }}</h3>
              </div>
            </div>
          </div>
          <div class="col-4">
            <div class="card">
              <div class="card-body">
                <h2 class="card-title">Total Books</h2>
                <h3 class="card-text">{{ total_books }}</h3>
                <button type="button" :class="{'btn btn-primary': !show_all_books, 'btn btn-secondary': show_all_books}" @click="showAllBooks">All Books</button>
                <button type="button" :class="{'btn btn-primary': !show_issued_books, 'btn btn-secondary': show_issued_books}" @click="showIssuedBooks">Issued Books</button>
                <button type="button" :class="{'btn btn-primary': !show_requested_books, 'btn btn-secondary': show_requested_books}" @click="showRequestedBooks">Requested Books</button>
                <div>
                    <button type="button" class="btn btn-warning" @click="checkOverdueBooks">Check Overdue Books</button>
                </div>
                </div>
            </div>
          </div>
          <div class="col-4">
            <div class="card">
              <div class="card-body">
                <h2 class="card-title">Total Sections</h2>
                <h3 class="card-text">{{ total_sections }}</h3>
                <button type="button" :class="{'btn btn-primary': !show_all_sections, 'btn btn-secondary': show_all_sections}" @click="showAllSections">All Sections</button>
                <button type="button" class="btn btn-outline-success" @click="download">Download</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    

    <div class="text-center">
        <button type="button" :class="{'btn btn-primary': !show_graphs, 'btn btn-secondary': show_graphs}" @click="showGraphs">Show Graphs</button>
    </div>
    <br>
    <div class="row justify-content-center" v-if="show_graphs">
        <div class="col text-center">
            <h3>Library Ratings</h3>
            <img src="static/images/rating_graph.png">
        </div>
        <div class="col text-center">
            <h3>Section Book Counts</h3>
            <img src="static/images/section_book_count_graph.png">
        </div>
    </div>

  
    <div v-if="show_all_books" class="container mt-5">
    <h2>All Books</h2>
    <button class="btn btn-success mb-3" @click="add_book">Add Book</button>
    <!-- Search input field -->
    <input type="text" v-model="search_query" class="form-control mb-3" placeholder="Search Books...  ">
    <div class="row row-cols-1 row-cols-md-3">
        <!-- Iterate over each book and display its details -->
        <div v-for="book in filteredBooks" :key="book.id" class="col mb-3 d-flex">
            <div class="card w-100">
                <div class="card-body d-flex flex-column">
                    <h5 class="card-title">{{ book.book_name }}</h5>
                    <p class="card-text">Section: {{ book.section_name }}</p>
                    <p class="card-text">Author: {{ book.author }}</p>
                    <p class="card-text">Description: {{ book.description }}</p>
                    
                    <!-- Action buttons -->
                   <div class="mt-auto">
                        <button type="button" class="btn btn-link" @click="editUploadBook(book.id)" style="position: absolute; bottom: 5px; left: 5px;">Edit</button>
                    </div>
                    <div class="text-center" v-if="editUploadBookClicked[book.id]">
                        <form @submit.prevent="save_changes_book(book.id)">
                            <label for="book_name" class="form-label">Book Name</label>
                            <input v-model="book_name" type="text" name="book_name" id="book_name" class="form-control" required>
                            <br>
                            <label for="author" class="form-label">Author</label>
                            <input v-model="author" type="text" name="author" id="author" class="form-control" required>
                            <br>
                            <label for="description" class="form-label">Description</label>
                            <textarea v-model="description" name="description" id="description" cols="8" rows="3" class="form-control" required></textarea>
                            <br>
                            <button type="submit" class="btn btn-success">Save Changes</button>
                            <button type="button" class="btn btn-secondary" @click="cancel_book(book.id)">Cancel</button>
                        </form>
                    </div>
                    <button class="btn btn-danger mt-auto align-self-end" @click="deleteBook(book.id)">Delete</button>
                </div>
            </div>
        </div>
        <!-- If no matching books found or no search query -->
        <div v-if="filteredBooks.length === 0" class="col-12">
            <p>No matching books found.</p>
        </div>
    </div>
</div>  

    <div v-if="show_all_sections" class="container mt-5">
    <h2>Sections</h2>
    <div class="mb-3">
      <button class="btn btn-success mb-3" @click="add_section">Add Section</button>
    </div>
    <div class="row">
      <div v-for="section in all_sections" :key="section.id" class="col-4 mb-3">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">{{ section.section_name }}</h5>
            <p class="card-text">{{ section.description }}</p>
            <button type="button" class="btn btn-link" @click="editUploadSection(section.id)">Edit</button>
            <button type="button" class="btn btn-danger" @click="deleteSection(section.id)">Delete</button>
            <div v-if="editSectionclicked[section.id]" class="mt-3">
              <form @submit.prevent="save_changes_section(section.id)">
                <label for="section_name" class="form-label">Section Name</label>
                <input v-model="section_name" type="text" name="section_name" id="section_name" class="form-control" required>
                <br>
                <label for="section_description" class="form-label">Section Description</label>
                <textarea v-model="section_description" name="section_description" id="section_description" cols="8" rows="3" class="form-control" required></textarea>
                <br>
                <button type="submit" class="btn btn-success">Save Changes</button>
                <button type="button" class="btn btn-secondary" @click="cancelEditSection(section.id)">Cancel</button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
        
<div v-if="show_requested_books">
    <h3>Requested Books</h3>
    <!-- Display requested books here as cards -->
    <div class="row justify-content-around">
        <div class="col-md-auto mb-2" v-for="book in requested_books" :key="book.id">
            <div class="card" style="width: 300px;">
                <div class="card-body d-flex flex-column">
                    <h5 class="card-title">Book Details</h5>
                    <p class="card-text">
                        <strong>Book Name:</strong> {{ book.book_name }}<br>
                        <strong>Author:</strong> {{ book.author }}
                    </p>
                    <button type="button" class="btn btn-success" @click="approve_book(book.id)">Approve</button>
                </div>
            </div>
        </div>
    </div>
</div>


<div v-if="show_issued_books">
    <h3>Issued Books</h3>
    <!-- Display issued books here as cards -->
    <div class="row justify-content-around">
        <div class="col-md-auto mb-2" v-for="book in issued_books" :key="book.id">
            <div class="card" style="width: 300px;">
                <div class="card-body">
                    <h5 class="card-header">Book Details</h5>
                    <div class="card-text">
                        <p><strong>Book Name:</strong> {{ book.book_name }}</p>
                        <p><strong>Author:</strong> {{ book.author }}</p>
                        <p><strong>Issued To:</strong> {{ book.username }}</p>
                    </div>
                    <button type="button" class="btn btn-danger" @click="revoke_access(book.id)">Revoke Access</button>
                </div>
            </div>
        </div>
    </div>
</div>

</div>




        `,
    data() {
        return {
            role: localStorage.getItem('role'),
            token: localStorage.getItem('auth_token'),
            all_books: [], // Array to store all books
            all_sections: [], // Array to store all sections
            all_users: [], // Array to store all users
            issued_books:[],
            requested_books:[],
            total_books: 0, // Total number of books
            total_users: 0, // Total number of users
            total_sections: 0, // Total number of sections
            show_all_books: false, // Boolean flag to toggle visibility of all books
            show_all_sections: false, // Boolean flag to toggle visibility of all sections
            show_issued_books: false, // Boolean flag to toggle visibility of issued books
            show_requested_books: false, // Boolean flag to toggle visibility of requested books
            show_graphs:false,
            search_query: null, // Search query entered by the user
            search_results: null, // Array to store search results
            edit_upload_clicked: {},
            editSectionclicked:{},
            editUploadBookClicked:{},
            section_name:'',
            section_description:'',
            book_name:'',
            author:'',
            description:''
        }
    },
    async mounted() {
        try {
            await this.app_data();
        } catch (err) {
            console.log("Some error occurred");
        }
    },
    methods: {
        async app_data() {
            const response = await fetch(`/app_data`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'Authentication-Token': this.token,

                },
            });
            if (response.status == 200) {
                const response_data = await response.json();
                console.log(response_data)
                // Update data properties
                this.all_books = response_data.books;
                this.all_sections = response_data.sections;
                this.all_users = response_data.users;
                this.total_books = this.all_books.length;
                this.total_users = this.all_users.length;
                this.total_sections = this.all_sections.length;
                // Filter issued books
                this.issued_books = this.all_books.filter(book => book.is_approved === true && book.is_requested === true);
        
                // Filter requested books
                this.requested_books = this.all_books.filter(book => book.is_requested === true && book.is_approved===false);
            } else {
                const error = await response.json();
                alert(error.message);
            }
        }
        ,
        showAllBooks() {
            this.show_all_books = true;
            this.show_issued_books = false;
            this.show_requested_books = false;
            this.show_all_sections = false;
            this.show_graphs = false;
        },
        showIssuedBooks() {
            this.show_all_books = false;
            this.show_issued_books = true;
            this.show_requested_books = false;
            this.show_all_sections = false;
            this.show_graphs = false;
        },
        showAllSections() {
            this.show_all_books = false;
            this.show_issued_books = false;
            this.show_requested_books = false;
            this.show_all_sections = true;
            this.show_graphs = false;
        },
        showRequestedBooks() {
            this.show_all_books = false;
            this.show_issued_books = false;
            this.show_requested_books = true;
            this.show_all_sections = false;
            this.show_graphs = false;
        },

        showGraphs() {
            this.show_graphs = true;
            this.show_all_books = false;
            this.show_issued_books = false;
            this.show_requested_books = false;
            this.show_all_sections = false;
        },

    async deleteBook(book_id) {
        const confirm_delete = window.confirm("Are you sure you want to delete this book?");
        if (confirm_delete) {
            try {
                const response = await fetch(`/delete_book/${book_id}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authentication-Token': this.token,
                    },
                });

                if (response.status === 200) {
                    const response_data = await response.json();
                    this.showSuccessAlert(response_data.message);
                    this.app_data(); // Update application data after successful deletion
                } else {
                    const error = await response.json();
                    alert(error.message);
                }
            } catch (error) {
                console.error("Error deleting book:", error);
                alert("An error occurred while deleting the book.");
            }
    }
},

async deleteSection(section_id) {
    const confirm_delete = window.confirm("Are you sure you want to delete this section?");
    if (confirm_delete) {
        try {
            const response = await fetch(`/delete_section/${section_id}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authentication-Token': this.token,
                },
            });

            if (response.status === 200) {
                const response_data = await response.json();
                this.showSuccessAlert(response_data.message);
                this.app_data(); // Update application data after successful deletion
            } else {
                const error = await response.json();
                alert(error.message);
            }
        } catch (error) {
            console.error("Error deleting section:", error);
            alert("An error occurred while deleting the section.");
        }
    }
},

async revoke_access(book_id) {
    const confirm_revoke = window.confirm("Are you sure you want to revoke access to this book?");
    if (confirm_revoke) {
        try {
            const response = await fetch(`/revoke_access/${book_id}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authentication-Token': this.token,
                },
            });

            if (response.status === 200) {
                const response_data = await response.json();
                this.showSuccessAlert(response_data.message);
                this.app_data(); // Update application data after successful access revocation
            } else {
                const error = await response.json();
                alert(error.message);
            }
        } catch (error) {
            console.error("Error revoking access to book:", error);
            alert("An error occurred while revoking access to the book.");
        }
    }
},
async checkOverdueBooks() {
    const confirmCheck = window.confirm("Are you sure you want to check overdue books?");
    if (confirmCheck) {
        try {
            const response = await fetch('/check_overdue_books', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authentication-Token': this.token,  
                },
            });

            if (response.ok) {
                const responseData = await response.json();
                this.showSuccessAlert(responseData.message);
                this.app_data(); 
            } else {
                const errorData = await response.json();
                alert(errorData.message);
            }
        } catch (error) {
            console.error("Error checking overdue books:", error);
            alert("An error occurred while checking overdue books.");
        }
    }
}
,
async approve_book(book_id) {
    const confirm_approve = window.confirm("Are you sure you want to approve this book?");
    if (confirm_approve) {
        try {
            const response = await fetch(`/approve_book/${book_id}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authentication-Token': this.token,
                },
            });

            if (response.status === 200) {
                const response_data = await response.json();
                this.showSuccessAlert(response_data.message);
                this.app_data(); // Update application data after successful book approval
            } else {
                const error = await response.json();
                alert(error.message);
            }
        } catch (error) {
            console.error("Error approving book:", error);
            alert("An error occurred while approving the book.");
        }
    }
},
editUploadBook(book_id) {
    this.$set(this.editUploadBookClicked, book_id, true);
    this.book_name = this.all_books.find(book => book.id == book_id).book_name;
    this.author = this.all_books.find(book => book.id == book_id).author;
    this.description = this.all_books.find(book => book.id == book_id).description;
    // Additional fields specific to book editing
},

cancel_book(book_id) {
    this.$set(this.editUploadBookClicked, book_id, false);
},

async download(){
    alert("Dowloading will start soon")
    const response = await fetch('/download')
     if (response.status == 200){
         const response_data = await response.json();
         const taskid = response_data['taskid']
        const intv = setInterval(async () => {
            const response = await fetch(`getcsv/${taskid}`)
            if(response.status == 200){
                clearInterval(intv)
                window.location.href = `getcsv/${taskid}`
            }
            else{
                alert("Unable to download")
            }
        }, 1000)
     }
     else {
         alert("Unable to download")
     }
},

async save_changes_book(book_id) {
  const inputData = {
      name: this.book_name,
      author: this.author,
      description: this.description
      // Add other fields as necessary
  };

  try {
      const response = await fetch(`/update_book/${book_id}`, {
          method: 'PUT',
          headers: {
              'Content-Type': 'application/json',
              'Authentication-Token': this.token
          },
          body: JSON.stringify(inputData)
      });

      if (response.status === 200) {
          const response_data = await response.json();
          this.showSuccessAlert(response_data.message);
          window.location.reload(); // Reload the page after successful changes
      } else {
          const error = await response.json();
          alert(error.message);
      }
  } catch (error) {
      console.error("Error saving changes to book:", error);
      alert("An error occurred while saving changes to the book.");
  }
}
,
editUploadSection(section_id) {
    this.$set(this.editSectionclicked, section_id, true);
    this.section_name = this.all_sections.find(section => section.id == section_id).section_name;
    this.section_description = this.all_sections.find(section => section.id == section_id).description;
    // Additional fields specific to section editing
},

cancelEditSection(section_id) {
    this.$set(this.editSectionclicked, section_id, false);
},

async save_changes_section(section_id) {
  const inputData = {
      section_name: this.section_name,
      description: this.section_description
      // Add other fields as necessary
  };

  try {
      const response = await fetch(`/update_section/${section_id}`, {
          method: 'PUT',
          headers: {
              'Content-Type': 'application/json',
              'Authentication-Token': this.token
          },
          body: JSON.stringify(inputData)
      });

      if (response.status === 200) {
          const response_data = await response.json();
          this.showSuccessAlert(response_data.message);
          window.location.reload(); // Reload the page after successful changes
      } else {
          const error = await response.json();
          alert(error.message);
      }
  } catch (error) {
      console.error("Error saving changes to section:", error);
      alert("An error occurred while saving changes to the section.");
  }
}
,
add_book() {
    // Redirect to the page for adding books
    return this.$router.push('/manage_books');
},

add_section() {
    // Redirect to the page for adding sections
    return this.$router.push('/manage_sections');
},
showSuccessAlert(message) {
    swal({
      title: "Success!",
      text: message,
      icon: "success",
      button: "OK",
    });
  },

  // Example of a reusable method to show error alert
  showErrorAlert(message) {
    swal({
      title: "Error!",
      text: message,
      icon: "error",
      button: "OK",
    });
  },

    }
,
computed: {
    filteredBooks() {
      if (!this.search_query) {
        return this.all_books;
      }

      const query = this.search_query.toLowerCase();

      return this.all_books.filter(book => {
        const bookName = book.book_name ? book.book_name.toString().toLowerCase() : '';
        const author = book.author ? book.author.toString().toLowerCase() : '';
        return bookName.includes(query) || author.includes(query);
      });
    }
}
}