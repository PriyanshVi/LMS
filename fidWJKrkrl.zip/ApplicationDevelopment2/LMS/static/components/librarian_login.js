export default {
    template: 
    `
    <div style="height: 100vh; background-image: url('static/images/librarian.jpg'); background-size: cover; background-position: center; display: flex; justify-content: center; align-items: center;">
    <div class="container" style="margin-top: 20px; align-items: center; display: flex; flex-direction: column; font-family: 'Times New Roman', Times, serif;">
    
        <div class="bg-light p-2 rounded shadow-sm text-center">
            <h4 class="mb-0">LIBRARIAN PLEASE LOGIN</h4>
        </div>
    
    <form @submit.prevent="login" class="mb-3 p-5 bg-light" style="margin-top: 10px;">
        <div class="mb-3">
            <label for="user_email" class="form-label">Email address</label>
            <input type="email" class="form-control" id="user_email" placeholder="name@example.com" v-model="login_details.email">
        </div>
        <div class="mb-3">
            <label for="user_password" class="form-label">Password</label>
            <input type="password" class="form-control" id="user_password" v-model="login_details.password">
        </div>
        <div class="text-center">
            <button type="submit" class="btn btn-primary">Login</button>
        </div>
        <br>
        <h6> 
            <button type="button" class="btn btn-link" @click="user_login">User Login</button>
        </h6>
    </form>
</div>
</div>`

    ,   data() {
        return {
            login_details: {
                email: null,
                password: null
            },
        }
    },
    methods: {
        async login() {
            const response = await fetch('/librarian_login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(this.login_details)
            })
            
            if (response.status == 200) {
                const response_data = await response.json();
                console.log(response_data.auth_token);
                console.log(response_data.role);
                localStorage.setItem('auth_token', response_data.auth_token);
                localStorage.setItem('role', response_data.role);
                
                if (response_data.role.includes('librarian')) {
                    this.$router.push('/library_dashboard')
                }
            }
            else {
                const error = await response.json();
                alert(error.message);
            }
        },
        user_login(){
            this.$router.push('/login')
        }
    },
}
