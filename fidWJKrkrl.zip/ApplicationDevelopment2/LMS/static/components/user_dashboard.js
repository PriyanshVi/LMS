export default {
    template: `
      <div>
        <div class="container text-center" v-if="!showBooks && !showAvailableBooks && !showContent">
          <h1>Welcome, {{ userName }}!</h1>
          <p>{{ motivationalQuote }}</p>
          <button class="btn btn-primary" @click="toggleSection('books')">Show My Books</button>
          <button class="btn btn-primary" @click="toggleSection('availableBooks')">Available Books to Request</button>
          <p class="motivational-text" style="font-style: italic; color: #555; margin-top: 20px;">"The only thing that you absolutely have to know, is the location of the library." - Albert Einstein</p>
          <p class="motivational-text" style="font-style: italic; color: #555; margin-top: 20px;">"A library is not a luxury but one of the necessities of life." - Henry Ward Beecher</p>
          <p class="motivational-text" style="font-style: italic; color: #555; margin-top: 20px;">"Libraries allow children to ask questions about the world and find the answers." - Laura Bush</p>
        
        </div>
  
        <div v-if="showBooks">
          <h2>My Books</h2>
          <button class="btn btn-secondary mb-3" @click="toggleSection('')">Back</button>
          <table class="table">
            <thead>
              <tr>
                <th>Book Title</th>
                <th>Author</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="book in userBooks" :key="book.book_id">
                <td>{{ book.book_name }}</td>
                <td>{{ book.author }}</td>
                <td>
                  <button class="btn btn-info" @click="readContent(book.id)">Read Content</button>
                  <button class="btn btn-success" @click="likeBook(book.id)">Like</button>
                  <button class="btn btn-danger" @click="dislikeBook(book.id)">Dislike</button>
                  <button class="btn btn-warning" @click="returnBook(book.id)">Return</button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
  
        <div v-if="showAvailableBooks">
          <h2>Available Books to Request</h2>
          <button class="btn btn-secondary mb-3" @click="toggleSection('')">Back</button>
          <input type="text" v-model="searchQuery" class="form-control mb-3" placeholder="Search Books...  ">
          
          <table class="table">
            <thead>
              <tr>
                <th>Book Title</th>
                <th>Author</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="book in filteredBooks" :key="book.book_id">
                <td>{{ book.book_name }}</td>
                <td>{{ book.author }}</td>
                <td>
                  <button class="btn btn-success" @click="requestBook(book.book_id)">Request</button>
                </td>
              </tr>
            </tbody>
          </table>
        <div v-if="filteredBooks.length === 0" class="col-12">
            <p>No matching books found.</p>
        </div>
        </div>
  
        <div v-if="showContent" style="padding: 20px; background-color: #f9f9f9; border-radius: 5px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); margin-top: 20px;">
  <h2>Content of {{ currentBook.book_name }}</h2>
  <button class="btn btn-secondary mb-3" @click="toggleSection('books')">Back</button>
  <div>
    <p>{{ currentBook.content }}</p>
    <p style="font-style: italic; color: #666; margin-top: 10px;">Written by {{ currentBook.author }}</p>
    <p style="color: #333; font-weight: bold; margin-top: 10px;">Rating: {{ currentBook.rating.toFixed(2) }}  </p>
  </div>
</div>

      </div>
    `,
  
    data() {
      return {
        userName: '',
        motivationalQuote: 'Keep learning and growing!',
        showBooks: false,
        showAvailableBooks: false,
        showContent: false,
        userBooks: [],  
        availableBooks: [],
        currentBook: {},
        searchQuery: null,
        searchResults: null,
        token: localStorage.getItem('auth_token'),
        role: localStorage.getItem('role'),
        
      };
    },
    
    async mounted() {
      await this.fetchUserName();
      await this.fetchUserBooks();
      await this.fetchAvailableBooks();
    },
    
    methods: {
      async fetchUserName() {
        const response = await fetch(`/user_name`, {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            'Authentication-Token': this.token,
          },
        });
        if (response.status === 200) {
          const data = await response.json();
          this.userName = data.username;
        } else {
          alert('Failed to fetch user name');
        }
      },
  
      async fetchUserBooks() {
        const response = await fetch(`/user_books`, {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            'Authentication-Token': this.token,
          },
        });
        if (response.status === 200) {
          const data = await response.json();
          this.userBooks = data.books;
          console.log(data)
        } else {
          alert('Failed to fetch user books');
        }
      },
      
      async fetchAvailableBooks() {
        const response = await fetch(`/available_books`, {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            'Authentication-Token': this.token,
          },
        });
        if (response.status === 200) {
          const data = await response.json();

          this.availableBooks = data.available_books_info;
        } else {
          alert('Failed to fetch available books');
        }
      },
      
      toggleSection(section) {
        this.showBooks = section === 'books';
        this.showAvailableBooks = section === 'availableBooks';
        this.showContent = section === 'content';
      },
      
      async readContent(bookId) {
        const response = await fetch(`/book_content/${bookId}`, {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            'Authentication-Token': this.token,
          },
        });
        if (response.status === 200) {
          const data = await response.json();
          this.currentBook = data.book;
          this.toggleSection('content');
        } else {
          alert('Failed to fetch book content');
        }
      },
      
      async requestBook(bookId) {
        try {
          const response = await fetch(`/request_book/${bookId}`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authentication-Token': this.token,
            },
          });
  
          if (response.status === 200) {
            this.showSuccessAlert("Book requested successfully");
            await this.fetchAvailableBooks(); // Example: Method to fetch updated book list
          } else {
            this.showErrorAlert("Failed to request book");
          }
        } catch (error) {
          this.showErrorAlert("An unexpected error occurred");
        }
      },
      async likeBook(bookId) {
        const response = await fetch(`/like_book/${bookId}`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authentication-Token': this.token,
          },
        });
        if (response.status === 200) {
          this.showSuccessAlert('Book liked successfully');
          await this.fetchUserBooks();
        } else {
          alert('Failed to like book');
        }
      },
      
      async dislikeBook(bookId) {
        const response = await fetch(`/dislike_book/${bookId}`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authentication-Token': this.token,
          },
        });
        if (response.status === 200) {
          this.showSuccessAlert('Book disliked successfully');
          await this.fetchUserBooks();
        } else {
          alert('Failed to dislike book');
        }
      },
      
      async returnBook(bookId) {
        const response = await fetch(`/return_book/${bookId}`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authentication-Token': this.token,
          },
        });
        if (response.status === 200) {
          this.showSuccessAlert("Book returned successfully");
          
          await this.fetchUserBooks();
        } else {
          alert('Failed to return book');
        }
      },
      showSuccessAlert(message) {
        swal({
          title: "Success!",
          text: message,
          icon: "success",
          button: "OK",
        });
      },
  
      // Example of a reusable method to show error alert
      showErrorAlert(message) {
        swal({
          title: "Error!",
          text: message,
          icon: "error",
          button: "OK",
        });
      },
    },

    computed: {
      filteredBooks() {
        if (!this.searchQuery) {
          return this.availableBooks;
        }
  
        const query = this.searchQuery.toLowerCase();
  
        return this.availableBooks.filter(book => {
          const bookName = book.book_name ? book.book_name.toString().toLowerCase() : '';
          const author = book.author ? book.author.toString().toLowerCase() : '';
          return bookName.includes(query) || author.includes(query);
        });
      }
      }
  };
  