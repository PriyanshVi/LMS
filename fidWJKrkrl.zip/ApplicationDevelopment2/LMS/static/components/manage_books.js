export default {
    template:
    `<div>
        <div class="text-center" style="margin-top: 20px">
            <form>
                <label for="book_name" class="form-label"><b>Title</b></label>
                <input v-model="book_details.book_name" type="text" id="book_name" name="book_name" class="form-control" required>
                <br>
                <label for="author" class="form-label"><b>Author</b></label>
                <input v-model="book_details.author" type="text" id="author" name="author" class="form-control" required>
                <br>
                <label for="description" class="form-label"><b>Description</b></label>
                <textarea v-model="book_details.description" id="description" name="description" rows="3" class="form-control" required></textarea>
                <br>
                <label for="content" class="form-label"><b>Content</b></label>
                <textarea v-model="book_details.content" id="content" name="content" rows="6" class="form-control" required></textarea>
                <br>
                <label for="section" class="form-label"><b>Section</b></label>
                <select v-model="selected_section" id="section" name="section" class="form-select" required>
                <option value="" disabled selected>Select Section</option>
                <option v-for="section in sections" :value="section.id">{{ section.section_name }}</option>
                </select>

                <br>
                <button type="button" class="btn btn-primary" @click="add_book">Add</button>
            </form>
        </div>
    </div>`,
    data() {
        return {
            book_details: {
                book_name: null,
                author: null,
                description: null,
                content: null, // Added content field here
                section_id: null,
            },
            sections: [], // Array to store fetched sections
            selected_section: null, // Selected section ID
            token: localStorage.getItem('auth_token'),
        }
    },
    async mounted() {
        try {
            await this.fetch_sections();
        } catch (err) {
            console.log("Some error occurred");
        }
    },
    methods: {
        async add_book() {
            if (!this.book_details.book_name || !this.book_details.author || !this.book_details.description || !this.book_details.content || !this.selected_section) {
                alert("Please enter all the details");
                return;
            }

            this.book_details.section_id = this.selected_section;

            try {
                const response = await fetch(`/add_book`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authentication-Token': this.token,
                    },
                    body: JSON.stringify(this.book_details),
                });

                if (response.status === 201) {
                    const response_data = await response.json();
                    alert(response_data.message);
                    this.$router.push('/library_dashboard'); // Redirect to the appropriate page after adding the book
                } else {
                    const error = await response.json();
                    alert(error.message);
                }
            } catch (error) {
                console.error("Error adding book:", error);
                alert("An error occurred while adding the book.");
            }
        },
        async fetch_sections() {
            try {
                const response = await fetch('/get_sections', {
                    headers: {
                        'Authentication-Token': this.token,
                    },
                });

                if (response.status === 200) {
                    this.sections = await response.json();
                    console.log(this.sections)
                } else {
                    const error = await response.json();
                    alert(error.message);
                }
            } catch (error) {
                console.error("Error fetching sections:", error);
                alert("An error occurred while fetching sections.");
            }
        },
    }
}
