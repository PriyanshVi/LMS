export default {
    template: `
    
    <div style="height: 100vh; background-image: url('static/images/library.jpeg'); background-size: cover; background-position: center; display: flex; justify-content: center; align-items: center;">
        <div class="container" style="margin-top: 20px; padding: 20px; display: flex; flex-direction: column; font-family: 'Arial', sans-serif; background-color: #f9f9f9; border-radius: 10px; box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); max-width: 600px;">
            <!-- Welcome Banner -->
            <div style="margin-bottom: 20px;">
                <div style="background-color: #ff6f61; padding: 15px; border-radius: 10px;">
                    <h3 style="color: white; font-size: 24px; text-align: center; margin: 0;">Welcome to the Library</h3>
                </div>
            </div>
           <!-- Buttons for navigation -->
            <div style="display: flex; flex-direction: column; align-items: center;">
                <button class="btn btn-primary" style="margin: 10px; background-color: #0e9aa7; border-color: #0e9aa7; width: 90%;" @click="userLogin">User Login</button>
                <button class="btn btn-primary" style="margin: 10px; background-color: #ffb703; border-color: #ffb703; width: 90%;" @click="librarianLogin">Librarian Login</button>
                <button class="btn btn-primary" style="margin: 10px; background-color: #ff6f61; border-color: #ff6f61; width: 90%;" @click="register">Register</button>
            </div>

            
            <!-- Quotes Section -->

            <!-- Quotes Section -->
            <div style="text-align: center; background-color: #FFF; padding: 20px; border-radius: 10px; box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); margin-top: 20px;">
                <p style="font-size: 18px; color: #333; margin-bottom: 15px;">"Libraries were full of ideas – perhaps the most dangerous and powerful of all weapons." - <span style="font-weight: bold; color: #0e9aa7;">Sarah J. Maas</span></p>
                <p style="font-size: 18px; color: #333; margin-bottom: 15px;">"I have always imagined that Paradise will be a kind of library." - <span style="font-weight: bold; color: #ffb703;">Jorge Luis Borges</span></p>
                <p style="font-size: 18px; color: #333;">"The only thing you absolutely have to know is the location of the library." - <span style="font-weight: bold; color: #ff6f61;">Albert Einstein</span></p>
            </div>
        </div>
        
    </div>`,
    methods: {
        userLogin() {
            this.$router.push('/login');
        },
        librarianLogin() {
            this.$router.push('/librarian_login');
        },
        register() {
            this.$router.push('/user_register');
        }
    },
}
