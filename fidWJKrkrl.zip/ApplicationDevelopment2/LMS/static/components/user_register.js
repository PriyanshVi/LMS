export default {
    template:
    `
    <div style="height: 100vh; background-image: url('static/images/library_student.jpeg'); background-size: cover; background-position: center; display: flex; justify-content: center; align-items: center;">
    <div class="container" style="margin-top: 20px; align-items: center; display: flex; flex-direction: column; font-family: Arial, sans-serif; width: 2000vw;">
        <h2 style="color: #333;">User Registration</h2>
        <div class="mb-3 p-5 bg-light" style="margin-top: 10px; border-radius: 10px; box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);">
            <label for="user_username" style="margin-bottom: 0;">Username</label>
            <input type="text" class="form-control" id="user_username" placeholder="Enter username" v-model="register_details.username" required>
            <label for="user_email" style="margin-bottom: 0;">Email address</label>
            <input type="email" class="form-control" id="user_email" placeholder="name@example.com" v-model="register_details.email" required>
            <label for="user_password" style="margin-bottom: 0;">Password</label>
            <input type="password" class="form-control" id="user_password" placeholder="Password" v-model="register_details.password" required>
            <label for="confirm_password" style="margin-bottom: 0;">Confirm Password</label>
            <input type="password" class="form-control" id="confirm_password" placeholder="Confirm Password" v-model="register_details.confirm_password" required>
            <br>
            <div class="text-center">
                <button type="button" class="btn btn-primary" @click="register" style="width: 100%;">Register</button>
            </div>
            <br>
            <h6> 
                Already Registered? <button type="button" class="btn btn-link" @click="login">Login</button>
            </h6>
        </div>
    </div>`,
    data() {
        return {
            register_details: {
                email: null,
                username: null,
                password: null,
                confirm_password: null
            },
        }
    },
    methods: {
        async register() {
            if (!this.isValidEmail(this.register_details.email)){
                alert("Invalid email address")
                return;
            }
            if (this.register_details.password !== this.register_details.confirm_password) {
                alert("Passwords do not match");
                return;
            }
            else{
                const response = await fetch('/user_register', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(this.register_details)
                })
                if (response.status == 200) {
                    const response_data = await response.json();
                    alert(response_data.message);
                    this.$router.push('/login')
                }
                else {
                    const error = await response.json();
                    alert(error.message);
                }

            }
            
        },
        login() {
            this.$router.push('/login');
        },
        isValidEmail(email) {
            // Regular expression for basic email validation
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return emailRegex.test(email);
        },
    },

}
