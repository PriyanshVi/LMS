export default {
    template:
    `<div>
        <div class="text-center" style="margin-top: 20px">
            <form>
                <label for="section_name" class="form-label"><b>Section Name</b></label>
                <input v-model="section_details.section_name" type="text" id="section_name" name="section_name" class="form-control" required>
                <br>
                <label for="section_description" class="form-label"><b>Section Description</b></label>
                <textarea v-model="section_details.description" id="section_description" name="section_description" rows="3" class="form-control" required></textarea>
                <br>
                <button type="button" class="btn btn-primary" @click="add_section">Add</button>
            </form>
        </div>
    </div>`,
    data() {
        return {
            section_details: {
                section_name: null,
                description: null,
            },
            token: localStorage.getItem('auth_token'),
        }
    },
    methods: {
        async add_section() {
            if (!this.section_details.section_name || !this.section_details.description) {
                alert("Please enter all the details");
                return;
            }

            try {
                const response = await fetch(`/add_section`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authentication-Token': this.token,
                    },
                    body: JSON.stringify(this.section_details),
                });

                if (response.status === 201) {
                    const response_data = await response.json();
                    alert(response_data.message);
                    this.$router.push('/library_dashboard'); // Redirect to the appropriate page after adding the section
                } else {
                    const error = await response.json();
                    alert(error.message);
                }
            } catch (error) {
                console.error("Error adding section:", error);
                alert("An error occurred while adding the section.");
            }
        }
    }
}
