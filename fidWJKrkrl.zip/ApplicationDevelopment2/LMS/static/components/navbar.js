export default {
    template: 
    `<nav class="navbar navbar-expand-lg navbar-light" style="background-color: #f8d7da;">
        <div class="container-fluid">
            <h3 class="navbar-brand" style="color: #721c24;">HOME</h3>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarScroll" aria-controls="navbarScroll" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarScroll">
                <ul v-if="!is_logged_in" class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <button class="nav-link btn btn-outline-primary" @click='login'>
                            Login
                        </button>
                    </li>
                    <li class="nav-item">
                        <button class="nav-link btn btn-outline-success" @click='librarian_login'>
                            Librarian Login
                        </button>
                    </li>
                </ul>
                <ul v-if="is_logged_in" class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <button class="nav-link btn btn-outline-info" @click='dashboard'>
                            <i class="bi bi-speedometer2"></i> Dashboard
                        </button>
                    </li>
                </ul>
                <ul v-if="is_logged_in" class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <button class="nav-link btn btn-outline-danger" @click='logout'>
                            <i class="bi bi-box-arrow-right"></i> Logout
                        </button>
                    </li>
                </ul>    
            </div>
        </div>
    </nav>`,
    data() {
        return {
            role: localStorage.getItem('role'),
            token: localStorage.getItem('auth_token'),
        }
    },
    methods: {
        logout() {
            localStorage.removeItem('auth_token');
            localStorage.removeItem('role');
            this.$router.push('/');
        },
        dashboard() {
            if (this.role === 'user') {
                this.$router.push('/user_dashboard');
            } else if (this.role === 'librarian') {
                this.$router.push('/library_dashboard');
            } else {
                console.log('Role not found');
            }
        },
        librarian_login() {
            this.$router.push('/librarian_login');
        },
        login() {
            this.$router.push('/login');
        },
    },
    computed: {
        is_logged_in() {
            return this.token !== null;
        }
    }
}
