export default {
    template: `
    <div class="container" style="max-width: 600px; margin: 20px auto; padding: 20px; background: #f9f9f9; border-radius: 12px; box-shadow: 0 6px 12px rgba(0,0,0,0.1);">
        <h3 class="title" style="text-align: center; margin-bottom: 20px; font-family: 'Arial', sans-serif; color: #2c3e50; font-weight: 700; font-size: 24px;">Add Section</h3>
        <form @submit.prevent="addSection" class="section-form" style="display: flex; flex-direction: column; gap: 20px;">
            <div class="form-group" style="display: flex; flex-direction: column;">
                <label for="sectionName" class="form-label" style="font-weight: 600; color: #e74c3c;">Section Name</label>
                <input type="text" id="sectionName" v-model="newSection.name" class="form-control" style="width: 100%; padding: 12px; border: 2px solid #e74c3c; border-radius: 8px; box-sizing: border-box; font-size: 16px; transition: border-color 0.3s ease; color: #2c3e50;" required>
            </div>
            <div class="form-group" style="display: flex; flex-direction: column;">
                <label for="sectionDescription" class="form-label" style="font-weight: 600; color: #3498db;">Description</label>
                <textarea id="sectionDescription" v-model="newSection.description" class="form-control" style="width: 100%; padding: 12px; border: 2px solid #3498db; border-radius: 8px; box-sizing: border-box; font-size: 16px; transition: border-color 0.3s ease; color: #2c3e50;" rows="4" required></textarea>
            </div>
            <button type="submit" class="btn" style="width: 100%; padding: 12px; background-color: #2ecc71; color: white; border: none; border-radius: 8px; cursor: pointer; font-size: 16px; font-weight: 600; transition: background-color 0.3s ease; box-shadow: 0 4px 8px rgba(0,0,0,0.2);">
                Add Section
            </button>
        </form>
    </div>
    `,
    data() {
        return {
            newSection: {
                name: '',
                description: ''
            },
            token: localStorage.getItem('auth_token'), // Retrieve token from localStorage
            role: localStorage.getItem('role') // Retrieve role from localStorage
        };
    },
    methods: {
        async addSection() {
            if (!this.token) {
                alert('User not authenticated');
                return;
            }

            // Post section data to the server
            const response = await fetch('/add_section', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authentication-Token': this.token,
                     // Directly include token in the Authorization header
                },
                body: JSON.stringify(this.newSection) // Directly include newSection data
            });

            if (response.ok) {
                alert('Section added successfully');
                this.$router.push('/library_dashboard'); // Redirect back to library dashboard
            } else {
                alert('Failed to add section');
            }
        }
    }
}
