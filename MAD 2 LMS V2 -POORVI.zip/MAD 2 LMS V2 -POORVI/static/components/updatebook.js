export default {
    template: `
    <div style="max-width: 600px; margin: auto; padding: 20px;">
        <div style="border-radius: 10px; border: 1px solid #ddd; box-shadow: 0 4px 8px rgba(0,0,0,0.1); overflow: hidden;">
            <div style="background-color: #007bff; color: white; padding: 15px; border-radius: 10px 10px 0 0;">
                <h3 style="margin: 0;">Update Book</h3>
            </div>
            <div style="padding: 20px;">
                <form @submit.prevent="updateBook">
                    <div style="margin-bottom: 1rem;">
                        <label for="bookId" style="display: block; font-weight: bold; margin-bottom: 0.5rem;">Book ID</label>
                        <input type="text" id="bookId" v-model="bookId" 
                               style="width: 100%; padding: 10px; border-radius: 5px; border: 1px solid #ced4da;" 
                               required readonly>
                    </div>
                    <div style="margin-bottom: 1rem;">
                        <label for="bookName" style="display: block; font-weight: bold; margin-bottom: 0.5rem;">Book Name</label>
                        <input type="text" id="bookName" v-model="book.name" 
                               style="width: 100%; padding: 10px; border-radius: 5px; border: 1px solid #ced4da;" 
                               required>
                    </div>
                    <div style="margin-bottom: 1rem;">
                        <label for="bookContent" style="display: block; font-weight: bold; margin-bottom: 0.5rem;">Content</label>
                        <textarea id="bookContent" v-model="book.content" 
                                  style="width: 100%; padding: 10px; border-radius: 5px; border: 1px solid #ced4da; resize: vertical;" 
                                  rows="4" required></textarea>
                    </div>
                    <button type="submit" 
                            style="width: 100%; padding: 10px; background-color: #28a745; color: white; border: none; border-radius: 5px; font-size: 16px; cursor: pointer;">
                        Update Book
                    </button>
                </form>
            </div>
        </div>
    </div>
    `,
    data() {
        return {
            bookId: this.$route.params.id || '', // Correctly extracting the bookId from route params
            book: {
                name: '',
                content: ''
            },
            role: localStorage.getItem('role'),
            token: localStorage.getItem('auth_token')
        };
    },
    async mounted() {
        // Fetch book details based on bookId
        if (this.bookId) {
            try {
                const response = await fetch(`http://127.0.0.1:5000/book/${this.bookId}`, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authentication-Token': this.token
                    }
                });
                
                if (response.ok) {
                    const bookData = await response.json();
                    // Prefill the form fields with fetched book details
                    this.book = {
                        name: bookData.name || '',
                        content: bookData.content || ''
                    };
                } else {
                    alert('Failed to fetch book details');
                }
            } catch (error) {
                console.error('Error fetching book details:', error);
                alert('Error fetching book details');
            }
        }
    },
    methods: {
        async updateBook() {
            try {
                const response = await fetch(`http://127.0.0.1:5000/update_book/${this.bookId}`, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authentication-Token': this.token,
                    },
                    body: JSON.stringify({
                        name: this.book.name,
                        content: this.book.content
                    })
                });
                if (response.ok) {
                    alert('Book updated successfully');
                    this.$router.push('/library_dashboard'); // Redirect back to dashboard
                } else {
                    alert('Failed to update book');
                }
            } catch (error) {
                console.error('Error updating book:', error);
                alert('Error updating book');
            }
        }
    }
};
