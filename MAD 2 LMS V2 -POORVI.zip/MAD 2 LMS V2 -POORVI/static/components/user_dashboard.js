export default {
    template: `
    <div class="dashboard-container">
        <div class="text-center mb-5">
            <h1>User Dashboard</h1>
            <h2>Welcome, {{ userName }}</h2>  <!-- Displaying the username -->
        </div>

        <div class="button-container mb-3">
            <button @click="toggleSection('myBooks')" class="btn btn-primary">My Books</button>
            <button @click="toggleSection('requestBooks')" class="btn btn-primary">Request Books</button>
        </div>

        <div v-if="show.myBooks" class="section-container mb-4">
            <h3>My Books</h3>
            <ul>
                <li v-for="book in myBooks" :key="book.request_id">
                    {{ book.book_name }}
                    <button @click="returnBook(book.request_id)" class="btn btn-warning btn-sm ml-2">Return</button>
                    <button @click="likeDislikeBook(book.book_id, 1)" class="btn btn-success btn-sm ml-2">Like</button>
                    <button @click="likeDislikeBook(book.book_id, 0)" class="btn btn-danger btn-sm ml-2">Dislike</button>
                    <button @click="readContent(book.book_id)" class="btn btn-info btn-sm ml-2">Read Content</button>
                </li>
            </ul>
        </div>

        <div v-if="show.requestBooks" class="section-container mb-4">
            <h3>Request Books</h3>
            <div class="mb-3">
                <input type="text" v-model="searchQuery" placeholder="Search Books" class="form-control" />
            </div>
            <ul>
                <li v-for="book in filteredBooks" :key="book.id">
                    {{ book.name }} by {{ book.author }}
                    <button @click="requestBook(book.id)" class="btn btn-primary btn-sm ml-2">Request Book</button>
                </li>
            </ul>
        </div>
    </div>
    `,
    data() {
        return {
            show: {
                myBooks: false,
                requestBooks: false
            },
            searchQuery: '',
            myBooks: [],
            availableBooks: [],
            userName: '',  // Added to hold the username
        };
    },
    async mounted() {
        try {
            await this.fetchUserName();  // Fetching the username
            await this.fetchUserBooks();
            await this.fetchAvailableBooks();
        } catch (err) {
            console.error("Error fetching data", err);
        }
    },
    computed: {
        filteredBooks() {
            return this.availableBooks.filter(book => {
                return book.name.toLowerCase().includes(this.searchQuery.toLowerCase()) ||
                       book.author.toLowerCase().includes(this.searchQuery.toLowerCase());
            });
        }
    },
    methods: {
        async fetchUserName() {
            const response = await fetch('/user_name', {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'Authentication-Token': localStorage.getItem('auth_token')
                }
            });
            if (response.ok) {
                const data = await response.json();
                this.userName = data.username;  // Set the username
            } else {
                alert('Failed to fetch user name');
            }
        },
        toggleSection(section) {
            this.show.myBooks = section === 'myBooks' ? !this.show.myBooks : false;
            this.show.requestBooks = section === 'requestBooks' ? !this.show.requestBooks : false;
        },
        async fetchUserBooks() {
            const response = await fetch('/user_books', {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'Authentication-Token': localStorage.getItem('auth_token')
                }
            });
            if (response.ok) {
                const data = await response.json();
                this.myBooks = data.remaining_requests;
            } else {
                alert('Failed to fetch user books');
            }
        },
        async fetchAvailableBooks() {
            const response = await fetch('/available_books', {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'Authentication-Token': localStorage.getItem('auth_token')
                }
            });
            if (response.ok) {
                const data = await response.json();
                this.availableBooks = data;
            } else {
                alert('Failed to fetch available books');
            }
        },
        async returnBook(requestId) {
            const response = await fetch(`/return_book/${requestId}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authentication-Token': localStorage.getItem('auth_token')
                }
            });
            if (response.ok) {
                alert('Book returned successfully');
                await this.fetchUserBooks();
            } else {
                alert('Failed to return book');
            }
        },
        async likeDislikeBook(bookId, value) {
            const response = await fetch(`/like_dislike/${bookId}/${value}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authentication-Token': localStorage.getItem('auth_token')
                }
            });
            if (response.ok) {
                alert('Like/Dislike updated successfully');
            } else {
                alert('Failed to update like/dislike');
            }
        },
        async requestBook(bookId) {
            const response = await fetch(`/request_book/${bookId}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authentication-Token': localStorage.getItem('auth_token')
                }
            });
            if (response.ok) {
                alert('Book request recorded');
                await this.fetchAvailableBooks();
            } else {
                alert('Failed to request book');
            }
        },
        readContent(bookId) {
            // This method should navigate to a page where the book's content is displayed
            this.$router.push(`/read_content/${bookId}`);
        }
    }
}
