export default {
    template: `
    <div class="dashboard-container" style="padding: 20px;">
        <div class="text-center mb-5">
            <h3>Library Dashboard</h3>
        </div>

        <div class="metrics-container mb-5">
            <h3>Metrics</h3>
            <ul>
                <li>Number of Users: {{ metrics.users }}</li>
                <li>Number of Books: {{ metrics.books }}</li>
                <li>Number of Sections: {{ metrics.sections }}</li>
            </ul>
        </div>

        <div class="button-container mb-3">
            <button @click="toggleSection('allBooks')" class="btn btn-primary">All Books</button>
            <button @click="toggleSection('allSections')" class="btn btn-primary">All Sections</button>
            <button @click="toggleSection('issuedBooks')" class="btn btn-primary">Issued Books</button>
            <button @click="toggleSection('requestedBooks')" class="btn btn-primary">Requested Books</button>
            <button type="button" class="btn btn-outline-success" @click="download">Download</button>
        </div>
        
        <div v-if="show.allBooks" class="section-container mb-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h3>All Books</h3>
                <button @click="createBook" class="btn btn-success">Create New Book</button>
            </div>
            
            <!-- Search Box -->
            <div class="mb-3">
                <input type="text" v-model="searchQuery" placeholder="Search Books" class="form-control" />
            </div>

            <ul>
                <li v-for="book in filteredBooks" :key="book.id">
                    {{ book.name }} by {{ book.author }}
                    <button @click="deleteBook(book.id)" class="btn btn-danger btn-sm ml-2">Delete</button>
                    <button @click="editBook(book.id)" class="btn btn-warning btn-sm ml-2">Edit</button>
                </li>
            </ul>
        </div>


        <div v-if="show.allSections" class="section-container mb-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h3>All Sections</h3>
                <button @click="createSection" class="btn btn-success">Create New Section</button>
            </div>
            <ul>
                <li v-for="section in sections" :key="section.id">
                    {{ section.name }}
                    <button @click="deleteSection(section.id)" class="btn btn-danger btn-sm ml-2">Delete</button>
                    <button @click="editSection(section.id)" class="btn btn-warning btn-sm ml-2">Edit</button>
                </li>
            </ul>
        </div>

        <div v-if="show.issuedBooks" class="section-container mb-4">
        <h3>Issued Books</h3>
        <ul>
            <li v-for="book in issuedBooks" :key="book.id">
                {{ book.book_name }} - Issued to {{ book.user_name }} (User ID: {{ book.user_id }})
                <button @click="revokeAccess(book.request_id)" class="btn btn-danger btn-sm ml-2">Revoke Access</button>
            </li>
        </ul>
        </div>

        <div v-if="show.requestedBooks" class="section-container mb-4">
            <h3>Requested Books</h3>
            <ul>
                <li v-for="book in requestedBooks" :key="book.id">
                    {{ book.book_name }} - Requested by {{ book.user_name }} (User ID: {{ book.user_id }})
                    <button @click="approveRequest(book.request_id)" class="btn btn-success btn-sm ml-2">Approve</button>
                </li>
            </ul>
        </div>


        <div v-if="!anySectionExpanded" class="chart-container mb-4">
            <canvas id="authorChart" style="max-width: 600px; height: 300px;"></canvas>
        </div>
        <div v-if="!anySectionExpanded" class="chart-container mb-4">
            <canvas id="sectionChart" style="max-width: 600px; height: 300px;"></canvas>
        </div>
        <div v-if="!anySectionExpanded" class="chart-container mb-4">
            <canvas id="ratingChart" style="max-width: 600px; height: 300px;"></canvas>
        </div>
    </div>
    `,
    data() {
        return {
            show: {
                allBooks: false,
                allSections: false,
                issuedBooks: false,
                requestedBooks: false
            },
            searchQuery: '',
            books: [],
            sections: [],
            issuedBooks: [],
            requestedBooks: [],
            metrics: {
                users: 0,
                books: 0,
                sections: 0
            },
            role: localStorage.getItem('role'),
            token: localStorage.getItem('auth_token')
        }
    },
    computed: {
        anySectionExpanded() {
            return Object.values(this.show).some(section => section);
        },
        filteredBooks() {
            return this.books.filter(book => {
                return book.name.toLowerCase().includes(this.searchQuery.toLowerCase()) ||
                       book.author.toLowerCase().includes(this.searchQuery.toLowerCase());
            });
        }
    },
    async mounted() {
        try {
            await this.fetchData();
            this.renderCharts();
        } catch (err) {
            console.log("Some error occurred");
        }
    },
    watch: {
        anySectionExpanded(newVal) {
            if (!newVal) {
                // If no section is expanded, re-render the charts
                this.$nextTick(() => {
                    this.renderCharts();
                });
            }
        }
    },
    methods: {
    
        toggleSection(section) {
            this.show[section] = !this.show[section];
    
            // Ensure other sections are closed
            if (this.show[section]) {
                Object.keys(this.show).forEach(key => {
                    if (key !== section) {
                        this.show[key] = false;
                    }
                });
            }
    
            // If the section is closed, check if all sections are closed, then render charts
            if (!this.anySectionExpanded) {
                this.$nextTick(() => {
                    this.renderCharts();
                });
            }
        },
        async  download() {
            alert("Downloading will start soon");
        
            try {
                const response = await fetch('/download');
                if (response.ok) {
                    const responseData = await response.json();
                    const taskId = responseData['taskid'];
        
                    const intv = setInterval(async () => {
                        try {
                            const checkResponse = await fetch(`getcsv/${taskId}`);
                            if (checkResponse.ok) {
                                clearInterval(intv);
                                window.location.href = `getcsv/${taskId}`;
                            } else if (checkResponse.status === 202) {
                                // Task is still pending
                                console.log("Task still pending...");
                            } else {
                                clearInterval(intv);
                                alert("Unable to download: Task failed");
                            }
                        } catch (error) {
                            clearInterval(intv);
                            console.error("Error checking task status:", error);
                            alert("An error occurred while checking task status.");
                        }
                    }, 1000);
                } else {
                    alert("Unable to start download: Task initiation failed");
                }
            } catch (error) {
                console.error("Error starting download:", error);
                alert("An error occurred while starting the download.");
            }
        }
        ,
        
        async fetchData() {
            const response = await fetch(`/app_data`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'Authentication-Token': this.token,
                }
            });
            if (response.ok) {
                const data = await response.json();
                this.books = data.books;
                this.sections = data.sections;
                this.issuedBooks = data.requests.filter(req => req.approved);
                this.requestedBooks = data.requests.filter(req => !req.approved);
                this.metrics.users = data.users.length;
                this.metrics.books = data.books.length;
                this.metrics.sections = data.sections.length;
            } else {
                alert('Failed to fetch data');
            }
        },
        async deleteBook(bookId) {
            const response = await fetch(`/delete_book/${bookId}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authentication-Token': this.token,
                }
            });
            if (response.ok) {
                alert('Book deleted successfully');
                await this.fetchData();
            } else {
                alert('Failed to delete book');
            }
        },
        async deleteSection(sectionId) {
            const response = await fetch(`/delete_section/${sectionId}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authentication-Token': this.token,
                }
            });
            if (response.ok) {
                alert('Section deleted successfully');
                await this.fetchData();
            } else {
                alert('Failed to delete section');
            }
        },
        async revokeAccess(requestId) {
            const response = await fetch(`/revoke_access/${requestId}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authentication-Token': this.token,
                }
            });
            if (response.ok) {
                alert('Access revoked successfully');
                await this.fetchData();
            } else {
                alert('Failed to revoke access');
            }
        },
        async approveRequest(requestId) {
            const response = await fetch(`/approve_request/${requestId}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authentication-Token': this.token,
                }
            });
            if (response.ok) {
                alert('Request approved successfully');
                await this.fetchData();
            } else {
                alert('Failed to approve request');
            }
        },
        createBook() {
            this.$router.push('/create_book');
        },
        createSection() {
            this.$router.push('/create_section');
        },
        editBook(bookId) {
            this.$router.push(`/update_book/${bookId}`);
        },
        editSection(sectionId) {
            this.$router.push(`/update_section/${sectionId}`);
        },
        renderCharts() {
            // Author vs Number of Books Chart
            const authorData = this.books.reduce((acc, book) => {
                acc[book.author] = (acc[book.author] || 0) + 1;
                return acc;
            }, {});
            new Chart(document.getElementById('authorChart'), {
                type: 'bar',
                data: {
                    labels: Object.keys(authorData),
                    datasets: [{
                        label: 'Number of Books',
                        data: Object.values(authorData),
                        backgroundColor: 'rgba(75, 192, 192, 0.2)',
                        borderColor: 'rgba(75, 192, 192, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    maintainAspectRatio: false,
                    responsive: true
                }
            });

            // Section vs Number of Books Chart
            const sectionData = this.sections.reduce((acc, section) => {
                acc[section.name] = section.books.length;
                return acc;
            }, {});
            new Chart(document.getElementById('sectionChart'), {
                type: 'bar',
                data: {
                    labels: Object.keys(sectionData),
                    datasets: [{
                        label: 'Number of Books',
                        data: Object.values(sectionData),
                        backgroundColor: 'rgba(153, 102, 255, 0.2)',
                        borderColor: 'rgba(153, 102, 255, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    maintainAspectRatio: false,
                    responsive: true
                }
            });

            // Rating vs Books Chart


            const bookNames = this.books.map(book => book.name);
            const bookRatings = this.books.map(book => book.rating);
        
            new Chart(document.getElementById('ratingChart'), {
                type: 'bar',
                data: {
                    labels: bookNames, // X-axis labels (Book names)
                    datasets: [{
                        label: 'Book Rating',
                        data: bookRatings, // Y-axis data (Ratings of the books)
                        backgroundColor: 'rgba(75, 192, 192, 0.2)',
                        borderColor: 'rgba(75, 192, 192, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    maintainAspectRatio: false,
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true,
                            title: {
                                display: true,
                                text: 'Rating'
                            }
                        },
                        x: {
                            title: {
                                display: true,
                                text: 'Books'
                            }
                        }
                    }
                }
            });
        }
    }
}
