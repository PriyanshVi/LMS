export function searchBooks(books, query) {
    if (!query) return books;
    return books.filter(book =>
        book.name.toLowerCase().includes(query.toLowerCase()) ||
        book.author.toLowerCase().includes(query.toLowerCase())
    );
}