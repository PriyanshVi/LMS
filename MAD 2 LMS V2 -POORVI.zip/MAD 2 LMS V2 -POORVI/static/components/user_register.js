export default {
    template: `
    <div style="height: 100vh; background-image: url('static/images/register.jpeg'); background-size: cover; background-position: center; display: flex; justify-content: center; align-items: center;">
    <div class="container" style="background: rgba(255, 255, 255, 0.8); padding: 2rem; border-radius: 10px; box-shadow: 0 0 20px rgba(0, 0, 0, 0.2); max-width: 400px; width: 100%; font-family: Arial, sans-serif;">
    <h2 style="color: #333; text-align: center; margin-bottom: 1.5rem;">User Registration</h2>
    <form @submit.prevent="register">
      <div class="form-group mb-3" style="margin-bottom: 1rem;">
        <label for="user_username" style="display: block; margin-bottom: 0.5rem;">Username</label>
        <input type="text" class="form-control" id="user_username" placeholder="Enter username" v-model="register_details.username" required style="width: 100%; padding: 0.5rem;">
      </div>
      <div class="form-group mb-3" style="margin-bottom: 1rem;">
        <label for="user_email" style="display: block; margin-bottom: 0.5rem;">Email address</label>
        <input type="email" class="form-control" id="user_email" placeholder="name@example.com" v-model="register_details.email" required style="width: 100%; padding: 0.5rem;">
      </div>
      <div class="form-group mb-3" style="margin-bottom: 1rem;">
        <label for="user_password" style="display: block; margin-bottom: 0.5rem;">Password</label>
        <input type="password" class="form-control" id="user_password" placeholder="Password" v-model="register_details.password" required style="width: 100%; padding: 0.5rem;">
      </div>
      <div class="form-group mb-3" style="margin-bottom: 1rem;">
        <label for="confirm_password" style="display: block; margin-bottom: 0.5rem;">Confirm Password</label>
        <input type="password" class="form-control" id="confirm_password" placeholder="Confirm Password" v-model="register_details.confirm_password" required style="width: 100%; padding: 0.5rem;">
      </div>
      <div class="text-center">
        <button type="submit" class="btn btn-primary" style="width: auto; padding: 0.5rem 2rem; font-size: 1rem;">Register</button>
      </div>
    </form>
    <div class="text-center mt-3">
      <h6 style="font-size: 1.2rem;">Already Registered? <button type="button" class="btn btn-link" @click="login">Login</button></h6>
    </div>
    </div>
    </div>

    `,
    data() {
        return {
            register_details: {
                email: null,
                username: null,
                password: null,
                confirm_password: null
            },
        }
    },
    methods: {
        async register() {
            if (!this.isValidEmail(this.register_details.email)) {
                alert("Invalid email address");
                return;
            }
            if (this.register_details.password !== this.register_details.confirm_password) {
                alert("Passwords do not match");
                return;
            } else {
                const response = await fetch(`/user_register`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(this.register_details)
                });
                if (response.status === 200) {
                    const response_data = await response.json();
                    alert(response_data.message);
                    this.$router.push('/login');
                } else {
                    const error = await response.json();
                    alert(error.message);
                }
            }
        },
        login() {
            this.$router.push('/login');
        },
        isValidEmail(email) {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return emailRegex.test(email);
        },
    }
}
