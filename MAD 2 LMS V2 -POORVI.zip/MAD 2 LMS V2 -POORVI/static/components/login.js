export default {
    template: `
    <div style="height: 100vh;background-image: url('static/images/userlogin.jpeg'); background-size: cover; background-position: center; display: flex; justify-content: center; align-items: center;">
        <div class="container" style="max-width: 400px; margin: auto;">
            <div class="card shadow-lg" style="padding: 20px; border-radius: 10px; background-color: #fff;">
                <h3 class="text-center mb-4" style="color: #333;">Login</h3>
                <form @submit.prevent="login">
                    <div class="mb-4">
                        <label for="user_email" class="form-label">Email address</label>
                        <input type="email" class="form-control" id="user_email" placeholder="name@example.com" v-model="login_details.email">
                    </div>
                    <div class="mb-4">
                        <label for="user_password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="user_password" v-model="login_details.password">
                    </div>
                    <div class="text-center mb-4">
                        <button type="submit" class="btn btn-primary w-100">Login</button>
                    </div>
                    <div class="text-center">
                        <p class="mb-0" style="color: #555;">New User? <button type="button" class="btn btn-link" @click="register">Register</button></p>
                    </div>
                </form>
            </div>
        </div>
    </div>`,
    data() {
        return {
            login_details: {
                email: null,
                password: null
            },
        }
    },
    methods: {
        async login() {
            if (!this.isValidEmail(this.login_details.email)) {
                alert("Invalid email address");
                return;
            } else {
                const response = await fetch('/user_login', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(this.login_details)
                });

                if (response.status === 200) {
                    const response_data = await response.json();
                    localStorage.setItem('auth_token', response_data.auth_token);
                    localStorage.setItem('role', response_data.role);

                    if (response_data.role.includes('librarian')) {
                        this.$router.push('/librarian_dashboard');
                    } else if (response_data.role.includes('user')) {
                        this.$router.push('/user_dashboard');
                    }
                } else {
                    const error = await response.json();
                    alert(error.message);
                }
            }
        },
        register() {
            this.$router.push('/user_register');
        },
        isValidEmail(email) {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return emailRegex.test(email);
        },
    },
    style: `
    .form-label {
        display: block;
        margin-bottom: .5rem;
    }
    
    .form-control {
        width: 100%;
        display: block;
        margin-bottom: .5rem;
    }
    `
}
