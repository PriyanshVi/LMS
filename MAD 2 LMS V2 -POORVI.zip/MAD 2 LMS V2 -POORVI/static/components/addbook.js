
export default {
    template: 
    `<div class="container" style="max-width: 600px; margin: 20px auto; padding: 20px; background: #ffffff; border-radius: 12px; box-shadow: 0 8px 16px rgba(0,0,0,0.1);">
        <h3 class="title" style="text-align: center; margin-bottom: 20px; font-family: 'Arial', sans-serif; color: #333; font-weight: 700;">Add Book</h3>
        <form @submit.prevent="addBook" class="book-form" style="display: flex; flex-direction: column; gap: 20px;">
            <div class="form-group" style="display: flex; flex-direction: column;">
                <label for="bookName" class="form-label" style="font-weight: 600; color: #333;">Book Name</label>
                <input type="text" id="bookName" v-model="newBook.name" class="form-control" style="width: 100%; padding: 12px; border: 2px solid #007bff; border-radius: 8px; box-sizing: border-box; transition: border-color 0.3s ease; font-size: 16px;" required>
            </div>
            <div class="form-group" style="display: flex; flex-direction: column;">
                <label for="bookAuthor" class="form-label" style="font-weight: 600; color: #007bff;">Author</label>
                <input type="text" id="bookAuthor" v-model="newBook.author" class="form-control" style="width: 100%; padding: 12px; border: 2px solid #007bff; border-radius: 8px; box-sizing: border-box; transition: border-color 0.3s ease; font-size: 16px;" required>
            </div>
            <div class="form-group" style="display: flex; flex-direction: column;">
                <label for="bookDescription" class="form-label" style="font-weight: 600; color: #28a745;">Description</label>
                <textarea id="bookDescription" v-model="newBook.description" class="form-control" style="width: 100%; padding: 12px; border: 2px solid #28a745; border-radius: 8px; box-sizing: border-box; transition: border-color 0.3s ease; font-size: 16px;" rows="4" required></textarea>
            </div>
            <div class="form-group" style="display: flex; flex-direction: column;">
                <label for="bookContent" class="form-label" style="font-weight: 600; color: #17a2b8;">Content</label>
                <textarea id="bookContent" v-model="newBook.content" class="form-control" style="width: 100%; padding: 12px; border: 2px solid #17a2b8; border-radius: 8px; box-sizing: border-box; transition: border-color 0.3s ease; font-size: 16px;" rows="4" required></textarea>
            </div>
            <div class="form-group" style="display: flex; flex-direction: column;">
                <label for="bookRating" class="form-label" style="font-weight: 600; color: #ffc107;">Rating</label>
                <input type="number" id="bookRating" v-model="newBook.rating" class="form-control" style="width: 100%; padding: 12px; border: 2px solid #ffc107; border-radius: 8px; box-sizing: border-box; transition: border-color 0.3s ease; font-size: 16px;" min="0" max="5" required>
            </div>
            <div class="form-group" style="display: flex; flex-direction: column;">
                <label for="bookSection" class="form-label" style="font-weight: 600; color: #343a40;">Section</label>
                <select id="bookSection" v-model="newBook.section_id" class="form-control" style="width: 100%; padding: 12px; border: 2px solid #343a40; border-radius: 8px; box-sizing: border-box; transition: border-color 0.3s ease; font-size: 16px;" required>
                    <option value="" disabled>Select a section</option>
                    <option v-for="section in sections" :key="section.id" :value="section.id">
                        {{ section.name }}
                    </option>
                </select>
            </div>
            <button type="submit" class="btn" style="width: 100%; padding: 14px; background-color: #007bff; color: white; border: none; border-radius: 8px; cursor: pointer; font-size: 18px; font-weight: 700; transition: background-color 0.3s ease; box-shadow: 0 4px 8px rgba(0,0,0,0.2);">
                Add Book
            </button>
        </form>
    </div>`
    ,
    data() {
        return {
            newBook: {
                name: '',
                author: '',
                description: '',
                content: '',
                rating: 0,
                section_id: ''
            },
            sections: [], // Array to hold sections
            token: localStorage.getItem('auth_token'), // Retrieve token from localStorage
            role: localStorage.getItem('role') // Retrieve role from localStorage
        };
    },
    async mounted() {
        // Fetch sections from the server
        const response = await fetch('/get_sections');
        if (response.ok) {
            this.sections = await response.json();
        } else {
            console.error('Failed to fetch sections');
        }
    },
    methods: {
        async addBook() {
            if (!this.token) {
                alert('User not authenticated');
                return;
            }

            // Post book data to the server
            const response = await fetch('/add_book', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authentication-Token': this.token, // Directly include token in the Authorization header
                },
                body: JSON.stringify(this.newBook) // Directly include newBook data
            });

            if (response.ok) {
                alert('Book added successfully');
                this.$router.push('/library_dashboard'); // Redirect back to dashboard
            } else {
                alert('Failed to add book');
            }
        }
    }
}

