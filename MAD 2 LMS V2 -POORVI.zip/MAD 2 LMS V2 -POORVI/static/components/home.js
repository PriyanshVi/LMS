export default {
    template: `
    <div style="height: 100vh; display: flex; justify-content: center; align-items: center; background-size: cover;background-position: center;background-color: #f5f5f5; background-image: url('static/images/home.jpeg');">
      <div style="background-color: #444; padding: 40px; border-radius: 10px; box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2); width: 400px; text-align: center; color: white;">
        <h2>Welcome</h2>
        <p>Choose an action:</p>
        <button @click="register" style="background-color: #007bff; border: none; color: white; padding: 10px 20px; margin: 10px 0; border-radius: 5px; cursor: pointer; width: 100%;">Register</button>
        <button @click="userLogin" style="background-color: #6c757d; border: none; color: white; padding: 10px 20px; margin: 10px 0; border-radius: 5px; cursor: pointer; width: 100%;">User Login</button>
        <button @click="librarianLogin" style="background-color: #17a2b8; border: none; color: white; padding: 10px 20px; margin: 10px 0; border-radius: 5px; cursor: pointer; width: 100%;">Librarian Login</button>
        <div style="margin-top: 20px; font-size: 14px;">
          <p>"The only thing that you absolutely have to know, is the location of the library." - Albert Einstein</p>
          <p>"I have always imagined that Paradise will be a kind of library." - Jorge Luis Borges</p>
          <p>"Libraries store the energy that fuels the imagination. They open up windows to the world and inspire us to explore and achieve, and contribute to improving our quality of life." - Sidney Sheldon</p>
        </div>
      </div>
    </div>`,
    methods: {
      userLogin() {
        this.$router.push('/login');
      },
      librarianLogin() {
        this.$router.push('/librarian_login');
      },
      register() {
        this.$router.push('/user_register');
      }
    }
  }
  