export default {
    template: `
    <div style="display: flex; justify-content: center; align-items: center; height: 100vh; background-color: #f8f9fa;">
        <div style="width: 70%; max-width: 800px; background-color: #fff; padding: 40px; border-radius: 15px; box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);">
            <h2 style="text-align: center; margin-bottom: 40px; color: #333;">Update Section</h2>
            <form @submit.prevent="updateSection">
                <div class="form-group" style="margin-bottom: 25px;">
                    <label for="sectionId" style="font-size: 1.2rem; color: #555; display: block;">Section ID</label>
                    <input type="text" id="sectionId" v-model="sectionId" readonly class="form-control" style="font-size: 1.2rem; padding: 15px; border: 1px solid #ccc; border-radius: 10px; background-color: #e9ecef; display: block; width: 100%;">
                </div>
                <div class="form-group" style="margin-bottom: 25px;">
                    <label for="sectionName" style="font-size: 1.2rem; color: #555; display: block;">Section Name</label>
                    <input type="text" id="sectionName" v-model="section.name" required class="form-control" style="font-size: 1.2rem; padding: 15px; border: 1px solid #ccc; border-radius: 10px; display: block; width: 100%;">
                </div>
                <div class="form-group" style="margin-bottom: 25px;">
                    <label for="sectionDescription" style="font-size: 1.2rem; color: #555; display: block;">Description</label>
                    <input type="text" id="sectionDescription" v-model="section.description" required class="form-control" style="font-size: 1.2rem; padding: 15px; border: 1px solid #ccc; border-radius: 10px; display: block; width: 100%;">
                </div>
                <button type="submit" class="btn btn-success btn-block" style="font-size: 1.2rem; padding: 15px; border-radius: 10px; width: 100%;">Update Section</button>
            </form>
        </div>
    </div>
    `,
    data() {
        return {
            sectionId: this.$route.params.sid || '',
            section: {
                name: '',
                description: ''
            },
            role: localStorage.getItem('role'),
            token: localStorage.getItem('auth_token')
        };
    },
    async mounted() {
        // Fetch section details based on sectionId
        if (this.sectionId) {
            try {
                const response = await fetch(`http://127.0.0.1:5000/section/${this.sectionId}`, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authentication-Token': this.token
                    }
                });
                if (response.ok) {
                    const sectionData = await response.json();
                    // Prefill the form fields with fetched section details
                    this.section = {
                        name: sectionData.name || '',
                        description: sectionData.description || ''
                    };
                } else {
                    alert('Failed to fetch section details');
                }
            } catch (error) {
                console.error('Error fetching section details:', error);
                alert('Error fetching section details');
            }
        }
    },
    methods: {
        async updateSection() {
            try {
                const response = await fetch(`http://127.0.0.1:5000/update_section/${this.sectionId}`, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authentication-Token': this.token
                    },
                    body: JSON.stringify(this.section)
                });
                if (response.ok) {
                    alert('Section updated successfully');
                    this.$router.push('/library_dashboard'); // Redirect back to dashboard
                } else {
                    alert('Failed to update section');
                }
            } catch (error) {
                console.error('Error updating section:', error);
                alert('Error updating section');
            }
        }
    }
};