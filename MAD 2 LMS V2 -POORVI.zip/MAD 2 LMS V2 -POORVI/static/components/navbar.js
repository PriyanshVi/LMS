export default {
    template: 
    `
    <div>
        <nav class="navbar navbar-expand-lg navbar-light" style="background: linear-gradient(to right, #87ceeb, #00bfff); padding: 1rem 2rem;">
            <div class="container-fluid">
                <h3 class="navbar-brand" style="color: #000; font-weight: bold; flex-grow: 1; text-align: center; font-size: 1.5rem;">
                    Library Management System
                </h3>
                
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarScroll" aria-controls="navbarScroll" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarScroll" style="flex-grow: 2;">
                    <ul class="navbar-nav ms-auto mb-2 mb-lg-0" style="display: flex; justify-content: space-between; width: 100%; list-style: none; padding-left: 0;">
                        <li class="nav-item" v-if="is_logged_in">
                            <button class="nav-link btn btn-sky-blue btn-lg mx-2" @click='dashboard' style="width: 100%; margin: 0 1rem; color: #000; font-size: 1.2rem;">
                                <i class="bi bi-speedometer2"></i> Dashboard
                            </button>
                        </li>
                        <li class="nav-item" v-if="!is_logged_in">
                            <button class="nav-link btn btn-sky-blue btn-lg mx-2" @click='login' style="width: 100%; margin: 0 1rem; color: #000; font-size: 1.2rem;">
                                Login
                            </button>
                        </li>
                        <li class="nav-item" v-if="!is_logged_in">
                            <button class="nav-link btn btn-sky-blue btn-lg mx-2" @click='librarian_login' style="width: 100%; margin: 0 1rem; color: #000; font-size: 1.2rem;">
                                Librarian Login
                            </button>
                        </li>
                        <li class="nav-item" v-if="is_logged_in">
                            <button class="nav-link btn btn-sky-blue btn-lg mx-2" @click='logout' style="width: 100%; margin: 0 1rem; color: #000; font-size: 1.2rem;">
                                <i class="bi bi-box-arrow-right"></i> Logout
                            </button>
                        </li>
                    </ul>    
                </div>
            </div>
        </nav>
        <style scoped>
            .btn-sky-blue {
                background-color: #87ceeb;
                color: #000;
                border: none;
            }

            .btn-sky-blue:hover {
                background-color: #00bfff;
                color: #000;
            }

            .navbar-nav .nav-item {
                flex: 1;
            }

            .navbar-nav .nav-link {
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100%;
            }
        </style>
    </div>
    `,
    data() {
        return {
            role: localStorage.getItem('role'),
            token: localStorage.getItem('auth_token'),
        }
    },
    methods: {
        logout() {
            localStorage.removeItem('auth_token');
            localStorage.removeItem('role');
            this.$router.push('/');
        },
        dashboard() {
            if (this.role === 'user') {
                this.$router.push('/user_dashboard');
            } else if (this.role === 'librarian') {
                this.$router.push('/library_dashboard');
            } else {
                console.log('Role not found');
            }
        },
        librarian_login() {
            this.$router.push('/librarian_login');
        },
        login() {
            this.$router.push('/login');
        },
    },
    computed: {
        is_logged_in() {
            return this.token !== null;
        }
    }
}
