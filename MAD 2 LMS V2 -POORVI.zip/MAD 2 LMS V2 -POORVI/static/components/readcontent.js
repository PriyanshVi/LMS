export default {
    template: `
    <div style="padding: 20px;">
        <h1>{{ book.name }}</h1>
        <h3>by {{ book.author }}</h3>
        <p>{{ book.description }}</p>
        <div style="margin-top: 20px;">
            <p>{{ book.content }}</p>
        </div>
        <button @click="goBack" style="background-color: #6c757d; border: none; color: white; padding: 10px 20px; border-radius: 5px; cursor: pointer;">Back to Dashboard</button>
    </div>
    `,
    data() {
        return {
            book: {
                name: '',
                author: '',
                description: '',
                content: ''
            }
        };
    },
    async mounted() {
        const bookId = this.$route.params.bookId;
        try {
            const response = await fetch(`/book_content/${bookId}`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'Authentication-Token': localStorage.getItem('auth_token')
                }
            });
            if (response.ok) {
                const data = await response.json();
                this.book = data;
            } else {
                alert('Failed to fetch book content');
            }
        } catch (err) {
            console.error("Error fetching book content", err);
        }
    },
    methods: {
        goBack() {
            this.$router.push('/user_dashboard');
        }
    }
};