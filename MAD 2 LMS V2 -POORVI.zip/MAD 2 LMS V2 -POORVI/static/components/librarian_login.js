export default {
    template: `
    <div style="height: 100vh; background-image: url('static/images/librarian.jpeg'); background-size: cover; background-position: center; display: flex; justify-content: center; align-items: center;">
      <div class="container" style="margin-top: 20px; align-items: center; display: flex; flex-direction: column; font-family: 'Times New Roman', Times, serif; background-color: rgba(255, 255, 255, 0.9); border-radius: 10px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); padding: 30px; max-width: 400px;">
        <div class="bg-light p-2 rounded shadow-sm text-center">
          <h4 class="mb-0">LIBRARIAN PLEASE LOGIN</h4>
        </div>
        
        <form @submit.prevent="login" class="mb-3" style="margin-top: 20px; width: 100%;">
          <div class="mb-3" style="margin-bottom: 20px;">
            <label for="user_email" class="form-label" style="display: block; margin-bottom: 5px;">Email address</label>
            <input type="email" class="form-control" id="user_email" placeholder="name@example.com" v-model="login_details.email" style="border-radius: 5px; padding: 10px; width: 100%;">
          </div>
          <div class="mb-3" style="margin-bottom: 20px;">
            <label for="user_password" class="form-label" style="display: block; margin-bottom: 5px;">Password</label>
            <input type="password" class="form-control" id="user_password" v-model="login_details.password" style="border-radius: 5px; padding: 10px; width: 100%;">
          </div>
          <div class="text-center" style="margin-bottom: 20px;">
            <button type="submit" class="btn btn-primary" style="background-color: #007bff; border: none; padding: 10px 20px; border-radius: 5px; cursor: pointer; width: 100%;">Login</button>
          </div>
          <h6 class="text-center" style="font-size: 16px;">
            User Login? <button type="button" class="btn btn-link" @click="user_login" style="color: #007bff; text-decoration: none; padding: 0; font-size: 16px;">User Login</button>
          </h6>
        </form>
      </div>
    </div>
    `,
    data() {
      return {
        login_details: {
          email: null,
          password: null
        },
      }
    },
    methods: {
      async login() {
        const response = await fetch('/librarian_login', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(this.login_details)
        })
        
        if (response.status == 200) {
          const response_data = await response.json();
          console.log(response_data.auth_token);
          console.log(response_data.role);
          localStorage.setItem('auth_token', response_data.auth_token);
          localStorage.setItem('role', response_data.role);
          
          if (response_data.role.includes('librarian')) {
            this.$router.push('/library_dashboard')
          }
        }
        else {
          const error = await response.json();
          alert(error.message);
        }
      },
      user_login(){
        this.$router.push('/login')
      }
    }
  }
  