import home from './components/home.js';
import librarian_login from './components/librarian_login.js';
import login from './components/login.js';
import user_register from './components/user_register.js';
import updatebook from './components/updatebook.js';
import updatesection from './components/updatesection.js';
import create_book from './components/create_book.js';
import create_section from './components/create_section.js';
import library_dashboard from './components/library_dashboard.js';
import user_dashboard from './components/user_dashboard.js';
import readcontent from './components/readcontent.js';
Vue.use(VueRouter);

const routes = [
    { path: '/', component: home },
    { path: '/login', component: login, name: 'login' },
    { path: '/librarian_login', component: librarian_login },
    { path: '/user_register', component: user_register },
    { path: '/update_book/:id', component: updatebook, name: 'update_book' },
    { path: '/update_section/:sid', component: updatesection, name: 'update_section' },
    { path: '/create_book', component: create_book },
    { path: '/create_section', component: create_section },
    { path: '/library_dashboard', component: library_dashboard },
    { path: '/user_dashboard', component: user_dashboard },
    { path: '/read_content/:bookId', component: readcontent, name: 'read_content' } ,
    
];

export default new VueRouter({
    routes,
});
