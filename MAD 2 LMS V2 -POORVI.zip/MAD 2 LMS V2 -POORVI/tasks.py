from celery import shared_task
from models import *
import flask_excel as excel
import csv
from smtplib import SMTP
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from jinja2 import Template
from datetime import datetime,timedelta
import os
import logging
import time 
SMTP_HOST='localhost'
SMTP_PORT=1025
SENDER_EMAIL='librarian@email.com'
SENDER_PASSWORD=''

@shared_task(ignore_result=False)
def create_resource_csv():
    try:
        time.sleep(5)  # Simulate some processing delay
        
        # Fetch data from the database
        book_data = Book.query.with_entities(Book.author, Book.bname).all()

        # Create a CSV response
        csv_output = excel.make_response_from_query_sets(book_data, ["author", "bname"], 'csv', file_name="books.csv")
        
        # Save the CSV file to the local filesystem
        file_path = './downloads/books.csv'
        with open(file_path, 'wb') as file:
            file.write(csv_output.data)
        
        return file_path  # Return the path of the created file
    except Exception as e:
        logging.error(f"Error in create_csv task: {e}")
        raise

def send_email(to,subject,content_body):
    msg=MIMEMultipart()
    msg['To']=to
    msg['Subject']=subject
    msg['From']=SENDER_EMAIL
    msg.attach(MIMEText(content_body,'html'))

    client=SMTP(host=SMTP_HOST,port=SMTP_PORT)
    client.send_message(msg=msg)
    client.quit()


@shared_task(ignore_result=True)
def monthly_reminder():
    # Query all users with the role 'user'
    users = User.query.join(UserRoles).join(Role).filter(Role.name == 'user').all()

    # Read the HTML template
    with open('report.html', 'r') as f:
        template = Template(f.read())

    for user in users:
        # Fetch books currently issued to the user
        currently_issued_books = Book.query.join(RequestBook, Book.bid == RequestBook.bid).filter(
            RequestBook.user_id == user.user_id, 
            RequestBook.approved == True
        ).all() 

        # Fetch all books in the system
        all_books = Book.query.all()

        # Fetch books liked by the user
        liked_books = Book.query.join(Like, Book.bid == Like.book_id).filter(
            Like.user_id == user.user_id, 
            Like.value == 1
        ).all()

        # Render the email content
        email_content = template.render(
            email=user.email,
            username=user.user_name,
            currently_issued_books=currently_issued_books,
            all_books=all_books,
            liked_books=liked_books
        )

        # Send the email
        try:
            send_email(user.email, 'Monthly Report', email_content)
        except Exception as e:
            # Log the error
            print(f"Failed to send email to {user.email}: {e}")

    return "Monthly Report Sent"




from json import dumps
from httplib2 import Http


@shared_task(ignore_result=False)
def daily_remainder():
    timestamp=datetime.utcnow()-timedelta(hours=24)
    #not_visited_users=User.query.filter(User.last_activity<timestamp).all()
    
    # FOR Testing
    not_visited_users = User.query.filter(User.last_activity < datetime.utcnow()).all()
    if not not_visited_users:
        return "no inactive users today"
    

    for user in not_visited_users:
        username=user.user_name
        if username!='librarian':
            send_notification(username)

    return 'Notification sent to google chat space'



def send_notification(username):
    url='https://chat.googleapis.com/v1/spaces/AAAAkZqUJUg/messages?key=AIzaSyDdI0hCZtE6vySjMm-WEfRq3CPzqKqqsHI&token=GDT4LKk1I6k1tV0vcFWqEXtgEXAtFGwRIAP0c-RRHtU'
    app_message={'text':f'Hello {username}! Adventure awaits in the pages of a new book. Visit the library app and discover something amazing today!'} 
    message_headers={"content-type":"application/json;charset=UTF-8"}
    http_obj=Http()
    response=http_obj.request(
        uri=url,
        method="POST",
        headers=message_headers,
        body=dumps(app_message)
    )