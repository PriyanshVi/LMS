from werkzeug.security import generate_password_hash
from datetime import datetime, timedelta
from models import db, Book, Section, User, Role, UserRoles, Like, RequestBook

def initialize_sample_data():
    from main import app
    with app.app_context():
        db.create_all()
        
        # Create roles
        user_role = Role.query.filter_by(name='user').first()
        if not user_role:
            user_role = Role(name='user', description='This is the user role')
            db.session.add(user_role)
        
        librarian_role = Role.query.filter_by(name='librarian').first()
        if not librarian_role:
            librarian_role = Role(name='librarian', description='This is the librarian role')
            db.session.add(librarian_role)
        db.session.commit()

        # Create librarian user if not exists
        librarian = User.query.filter_by(email='librarian@email.com').first()
        if not librarian:
            librarian = User(
                user_name='librarian',
                email='librarian@email.com',
                password=generate_password_hash('librarian'),
                active=True,
                fs_uniquifier='librarian_unique',
                last_activity=datetime.utcnow()
            )
            db.session.add(librarian)
            db.session.commit()

            # Assign the librarian role
            librarian_role_assignment = UserRoles(user_id=librarian.user_id, role_id=librarian_role.id)
            db.session.add(librarian_role_assignment)
            db.session.commit()

        # Create a normal user
        normal_user = User.query.filter_by(email='user@email.com').first()
        if not normal_user:
            normal_user = User(
                user_name='normaluser',
                email='user@email.com',
                password=generate_password_hash('password'),
                active=True,
                fs_uniquifier='normaluser_unique',
                last_activity=datetime.utcnow()
            )
            db.session.add(normal_user)
            db.session.commit()

            # Assign the user role
            user_role_assignment = UserRoles(user_id=normal_user.user_id, role_id=user_role.id)
            db.session.add(user_role_assignment)
            db.session.commit()

        # Sample sections
        sections = [
            Section(sname="Fiction", sdescription="Fictional works including novels, short stories, etc."),
            Section(sname="Science", sdescription="Books related to science and technology."),
            Section(sname="History", sdescription="Books on historical events and figures."),
            Section(sname="Biography", sdescription="Biographies and autobiographies of famous personalities."),
            Section(sname="Philosophy", sdescription="Books on philosophical thoughts and theories."),
        ]

        # Adding sections if they don't already exist
        for section in sections:
            existing_section = Section.query.filter_by(sname=section.sname).first()
            if not existing_section:
                db.session.add(section)

        db.session.commit()

        # Sample books
        books = [
            Book(bname="To Kill a Mockingbird", author="Harper Lee", description="A novel addressing themes of racial injustice and moral growth in the 1930s American South.", content="Set in the fictional town of Maycomb, Alabama, the novel follows Scout Finch, a young girl who witnesses her father, lawyer Atticus Finch, defend a black man falsely accused of raping a white woman. Through Scout's innocent perspective, the novel explores deep-seated prejudices and the complexities of human nature.", section_id=1),
            Book(bname="A Brief History of Time", author="Stephen Hawking", description="A best-selling popular science book on cosmology and the universe's origins.", content="In 'A Brief History of Time', Stephen Hawking explains complex theories of space and time, black holes, and the Big Bang in a comprehensible manner. He discusses the nature of the universe, from its birth to its eventual fate, captivating readers with his insights into the mysteries of the cosmos.", section_id=2),
            Book(bname="The Diary of a Young Girl", author="Anne Frank", description="The diary of Anne Frank, a Jewish teenager who hid from the Nazis in Amsterdam during World War II.", content="Anne Frank's diary provides an intimate account of her life in hiding, offering poignant reflections on adolescence, love, and hope amidst the horrors of war. Her diary has become a symbol of resilience and courage, reminding readers of the human spirit's ability to endure in the face of adversity.", section_id=3),
            Book(bname="Steve Jobs", author="Walter Isaacson", description="A biography detailing the life, career, and legacy of Apple co-founder Steve Jobs.", content="Walter Isaacson's biography of Steve Jobs chronicles his visionary leadership at Apple, his innovative spirit in technology, and his tumultuous personal life. From the creation of iconic products like the iPhone to his challenging relationships, the biography delves deep into the complexities of one of Silicon Valley's most influential figures.", section_id=4),
            Book(bname="Meditations", author="Marcus Aurelius", description="A collection of personal writings by Roman Emperor Marcus Aurelius, offering philosophical reflections on life and leadership.", content="Marcus Aurelius' 'Meditations' presents philosophical reflections on Stoicism, exploring themes of virtue, resilience, and acceptance of fate. Written as a series of notes to himself, the writings provide timeless wisdom and practical advice on navigating life's challenges with integrity and inner peace.", section_id=5),
        ]

        # Adding books if they don't already exist
        for book in books:
            existing_book = Book.query.filter_by(bname=book.bname).first()
            if not existing_book:
                db.session.add(book)

        db.session.commit()

        # Sample likes associated with normal user only
        user = User.query.filter_by(email='user@email.com').first()
        if user:
            likes = [
                Like(value=True, book_id=1, user_id=user.user_id),
                Like(value=True, book_id=2, user_id=user.user_id),
                Like(value=False, book_id=3, user_id=user.user_id),
                Like(value=True, book_id=4, user_id=user.user_id),
                Like(value=False, book_id=5, user_id=user.user_id),
            ]

            for like in likes:
                existing_like = Like.query.filter_by(book_id=like.book_id, user_id=like.user_id).first()
                if not existing_like:
                    db.session.add(like)

            db.session.commit()

        # Sample requests for books associated with normal user only
        requests = [
            RequestBook(user_id=user.user_id, bid=1, bname="To Kill a Mockingbird", approved=False, return_date=None),
            RequestBook(user_id=user.user_id, bid=2, bname="A Brief History of Time", approved=True, return_date=datetime.utcnow() + timedelta(days=7)),
        ]

        for request in requests:
            existing_request = RequestBook.query.filter_by(bid=request.bid, user_id=request.user_id).first()
            if not existing_request:
                db.session.add(request)

        db.session.commit()

        print("Sample data initialized successfully.")
