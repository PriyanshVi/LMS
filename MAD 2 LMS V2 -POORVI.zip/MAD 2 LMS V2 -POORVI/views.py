from flask import current_app as app, jsonify, render_template, request, send_file
from flask_security import auth_required, roles_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from models import db, User, Book,Section,Role,Like,RequestBook  
from datastorefile import datastore
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import os
from datetime import datetime,timedelta
from flask_login import LoginManager,login_required,current_user,UserMixin,login_user, logout_user, login_required
from celery.result import AsyncResult
from cache import cache
from tasks import create_resource_csv
import logging
from sqlalchemy import select

@app.get('/')
def home():
    return render_template('index.html')


@app.post('/librarian_login')
def librarian_login():
    input_data=request.get_json()
    input_email = input_data.get('email')
    input_password = input_data.get('password')

    if not input_email or not input_password:
        return jsonify({'message': 'Email and Password are required.'}), 400
    
    if input_email != 'librarian@email.com':
        return jsonify({'message': 'Invalid Email ID'}), 400

    user = datastore.find_user(email=input_email)

    if not user:
        return jsonify({'message': 'User not found'}), 404

    if not user.check_password(input_password):
        return jsonify({'message': 'Incorrect Password'}), 400

    user.last_activity = datetime.utcnow()
    db.session.commit()
    books=Book.query.all()
    sections=Section.query.all()
    
    return jsonify({'auth_token': user.get_auth_token(), 'role': [role.name for role in user.roles]}), 200

@app.get('/user_name')
@login_required
@auth_required('token')
@roles_required('user')
def get_user_name():
    return jsonify({'username': current_user.user_name})

@app.post('/user_register')
def user_register():
    input_data= request.get_json()
    input_email= input_data.get('email')
    input_username= input_data.get('username')
    input_password= input_data.get('password')

    if not input_email or not input_username or not input_password:
        return jsonify({'message': 'Email, Username and Password are required.'}), 400
    
    if not datastore.find_user(email=input_email):
        datastore.create_user(email=input_email, user_name= input_username, password= generate_password_hash(input_password), roles=['user'])
        db.session.commit()
        return jsonify({'message': 'User registered successfully. You can login now.'}), 200
    else:
        return jsonify({'message': 'Email already registered.'}), 409


@app.post('/user_login')
def user_login():
    input_data = request.get_json()
    input_email = input_data.get('email')
    input_password = input_data.get('password')

    if not input_email or not input_password:
        return jsonify({'message': 'Email and Password are required.'}), 400
    
    if input_email == 'librarian@email.com':
        return jsonify({'message': 'Invalid Email ID'}), 400
    
    user = datastore.find_user(email=input_email)

    if not user:
        return jsonify({'message': 'User not found. Register first.'}), 404
    if not user.check_password(input_password):
        return jsonify({'message': 'Incorrect Password'}), 401
    login_user(user)
    user.last_activity = datetime.utcnow()
    db.session.commit()
    return jsonify({'auth_token': user.get_auth_token(), 'role': [role.name for role in user.roles]}), 200

@app.get('/user_data')
@auth_required('token')
@roles_required('user')
#@cache.cached(timeout=50)
def user_data():
    # Fetch all users
    users = User.query.all()
    all_users = [{'id': user.user_id, 'email': user.email, 'username': user.user_name, 'active': user.active, 
                  'roles': [role.name for role in user.roles]} for user in users]
    
    # Fetch all books
    books = Book.query.all()
    all_books = [{'id': book.bid, 'name': book.bname, 'author': book.author, 'description': book.description, 
                  'content': book.content, 'section_id': book.section_id, 
                  'section_name': Section.query.get(book.section_id).sname if Section.query.get(book.section_id) else None, 
                  'rating': book.rating} for book in books]
    
    # Fetch all request books for the current user
    user_id = current_user.user_id
    requests = RequestBook.query.filter_by(user_id=user_id).all()
    all_requests = [{'request_id': req.request_id, 'book_id': req.bid, 'book_name': req.bname, 
                     'approved': req.approved, 'return_date': req.return_date} for req in requests]
    
    # Fetch all sections
    sections = Section.query.all()
    all_sections = [{'id': section.sid, 'name': section.sname, 'description': section.sdescription, 
                     'books': [book.bname for book in section.books]} for section in sections]

    # Combine all data and return as JSON
    return jsonify({'users': all_users, 'books': all_books, 'requests': all_requests, 'sections': all_sections}), 200





@app.get('/app_data')
@auth_required('token')
@roles_required('librarian')
#@cache.cached(timeout=50) 
def app_data():
    # Fetch all roles
    roles = Role.query.all()
    all_roles = [{'id': role.id, 'name': role.name, 'description': role.description} for role in roles]

    # Fetch all users
    users = User.query.all()
    all_users = [{'id': user.user_id, 'email': user.email, 'username': user.user_name, 'active': user.active, 
                  'roles': [role.name for role in user.roles]} for user in users]
    
    # Fetch all books
    books = Book.query.all()
    all_books = [{'id': book.bid, 'name': book.bname, 'author': book.author, 'description': book.description, 
                  'content': book.content, 'section_id': book.section_id, 
                  'section_name': Section.query.get(book.section_id).sname if Section.query.get(book.section_id) else None, 
                  'rating':book.rating} for book in books]
    
    # Fetch all request books
    requests = RequestBook.query.all()
    all_requests = [{'request_id': req.request_id, 'user_id': req.user_id,'user_name': User.query.get(req.user_id).user_name if User.query.get(req.user_id) else None, 
                      'book_id': req.bid,'book_name': req.bname, 'approved': req.approved, 'return_date': req.return_date} for req in requests]
    
    # Fetch all sections
    sections = Section.query.all()
    all_sections = [{'id': section.sid, 'name': section.sname, 'description': section.sdescription, 
                     'books': [book.bname for book in section.books]} for section in sections]

    # Combine all data and return as JSON
    return jsonify({'roles': all_roles, 'users': all_users, 'books': all_books, 'requests': all_requests, 'sections': all_sections}), 200


@app.get('/get_sections')
@auth_required('token')
@roles_required('librarian')
def get_sections():
    # Fetch all sections
    sections = Section.query.all()
    all_sections = [{'id': section.sid, 'name': section.sname, 'description': section.sdescription, 
                     'books': [book.bname for book in section.books]} for section in sections]

    # Return sections as JSON
    return jsonify({'sections': all_sections}), 200

@app.post('/add_book')
@auth_required('token')
@roles_required('librarian')
def add_book():
    try:
        # Get data from the request
        data = request.get_json()
        if not data:
            return jsonify({'error': 'Invalid input'}), 400

        name = data.get('name')
        author = data.get('author')
        description = data.get('description')
        content = data.get('content')
        rating = data.get('rating')
        section_id = data.get('section_id')

        # Validate the input
        if not (name and author and description and content and rating is not None and section_id):
            return jsonify({'error': 'Missing required fields'}), 400

        # Ensure the rating is within the valid range
        if not (0 <= rating <= 5):
            return jsonify({'error': 'Rating must be between 0 and 5'}), 400

        # Find the section by ID
        section = Section.query.get(section_id)
        if not section:
            return jsonify({'error': 'Section not found'}), 404

        # Create a new book instance
        new_book = Book(
            bname=name,
            author=author,
            description=description,
            content=content,
            section_id=section_id,
            rating=rating
        )

        # Add and commit the new book to the database
        db.session.add(new_book)
        db.session.commit()

        return jsonify({'message': 'Book added successfully'}), 201

    except Exception as e:
        # Handle any exceptions that occur
        return jsonify({'error': str(e)}), 500


@app.get('/available_books')
@login_required
@auth_required('token')
@roles_required('user')
def available_books():
    user_id = current_user.user_id

    # Subquery to get book IDs that the current user has requested
    requested_books_subquery = select(RequestBook.bid).filter_by(user_id=user_id).subquery()

    # Query to get books that the user has not requested
    available_books = db.session.query(Book).filter(~Book.bid.in_(requested_books_subquery)).all()

    books = [{
        'id': book.bid,
        'name': book.bname,
        'author': book.author,
        'description': book.description,
        'content': book.content,
        'section_id': book.section_id,
        'rating': book.rating
    } for book in available_books]

    return jsonify(books)



@app.get('/user_name')
@login_required
@auth_required('token')
@roles_required('user')
def fetch_user_name():
    return jsonify({'user_name': current_user.user_name})

@app.post('/add_section')
@auth_required('token')
@roles_required('librarian')
def add_section():
    data = request.get_json()
    sname = data.get('name')  # Changed key to 'name' for consistency with Vue component
    sdescription = data.get('description')  # Changed key to 'description'

    if not sname or not sdescription:
        return jsonify({"error": "Missing section name or description"}), 400

    new_section = Section(sname=sname, sdescription=sdescription)  # Ensure keys match with your Section model
    db.session.add(new_section)
    db.session.commit()

    return jsonify({"message": "Section added successfully"}), 201

@app.post('/delete_book/<int:book_id>')
@auth_required('token')
@roles_required('librarian')
def delete_book(book_id):
    # Fetch the book from the database using the book_id
    book = Book.query.get(book_id)
    
    if book:
        # Delete all associated RequestBook entries
        request_count = RequestBook.query.filter_by(bid=book_id).delete()
        
        # Delete all associated Like entries
        like_count = Like.query.filter_by(book_id=book_id).delete()
        
        # Delete the book from the database
        db.session.delete(book)
        db.session.commit()
        
        return jsonify({
            "message": "Book and associated requests and likes deleted successfully",
            "requests_deleted": request_count,
            "likes_deleted": like_count
        }), 200
    else:
        # Return an error message if the book is not found
        return jsonify({"error": "Book not found"}), 404


@app.get('/section/<int:section_id>')
@auth_required('token')
@roles_required('librarian')
def section(section_id):
    try:
        # Get the section by ID
        section = Section.query.get(section_id)
        if not section:
            return jsonify({'error': 'Section not found'}), 404

        # Prepare the section details
        section_details = {
            'name': section.sname,
            'description': section.sdescription,
            # Include other fields if needed
        }

        return jsonify(section_details), 200

    except Exception as e:
        # Handle any exceptions that occur
        return jsonify({'error': str(e)}), 500
    


@app.post('/delete_section/<int:section_id>')
@auth_required('token')
@roles_required('librarian')
def delete_section(section_id):
    # Fetch the section from the database using the section_id
    section = Section.query.get(section_id)
    
    if section:
        # Find all books in this section
        books = section.books  # This will use the relationship defined with cascade
        
        # Extract all book IDs
        book_ids = [book.bid for book in books]
        
        # Delete all associated RequestBook entries for these books
        request_books = RequestBook.query.filter(RequestBook.bid.in_(book_ids)).all()
        for request in request_books:
            db.session.delete(request)
        
        # Delete all associated Like entries for these books
        like_entries = Like.query.filter(Like.book_id.in_(book_ids)).all()
        for like in like_entries:
            db.session.delete(like)
        
        # Delete all books in the section
        # (This is technically redundant due to cascade, but ensures clarity)
        for book in books:
            db.session.delete(book)
        
        # Delete the section
        db.session.delete(section)
        db.session.commit()
        
        return jsonify({
            "message": "Section and associated books, requests, and likes deleted successfully",
            "requests_deleted": len(request_books),
            "likes_deleted": len(like_entries)
        }), 200
    else:
        # Return an error message if the section is not found
        return jsonify({"error": "Section not found"}), 404


@app.put('/update_book/<int:book_id>')
@auth_required('token')
@roles_required('librarian')
def update_book(book_id):
    try:
        # Get the book to update
        book = Book.query.get(book_id)
        if not book:
            return jsonify({'error': 'Book not found'}), 404

        # Get data from the request
        data = request.get_json()
        if not data:
            return jsonify({'error': 'Invalid input'}), 400

        # Update only the name and content fields if provided
        if 'name' in data:
            book.bname = data['name']
        if 'content' in data:
            book.content = data['content']

        # Commit changes to the database
        db.session.commit()

        return jsonify({'message': 'Book updated successfully'}), 200

    except Exception as e:
        # Handle any exceptions that occur
        return jsonify({'error': str(e)}), 500
    


@app.get('/book/<int:book_id>')
@roles_required('librarian')
@auth_required('token')
def get_book(book_id):
    try:
        # Get the book by ID
        book = Book.query.get(book_id)
        if not book:
            return jsonify({'error': 'Book not found'}), 404

        # Prepare the book details
        book_details = {
            'name': book.bname,
            'content': book.content,
            # Note: `author` and `rating` are not included here
        }

        return jsonify(book_details), 200

    except Exception as e:
        # Handle any exceptions that occur
        return jsonify({'error': str(e)}), 500
    

@app.get('/section/<int:section_id>')
@auth_required('token')
@roles_required('librarian')
def get_section(section_id):
    try:
        section = Section.query.get(section_id)
        if not section:
            return jsonify({'error': 'Section not found'}), 404

        section_details = {
            'name': section.sname,
            'description': section.description,
        }

        return jsonify(section_details), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500




@app.put('/update_section/<int:section_id>')
@auth_required('token')
@roles_required('librarian')
def update_section(section_id):
    try:
        section = Section.query.get(section_id)
        if not section:
            return jsonify({'error': 'Section not found'}), 404

        data = request.get_json()
        if not data:
            return jsonify({'error': 'Invalid input'}), 400

        if 'name' in data:
            section.sname = data['name']
        if 'description' in data:
            section.description = data['description']

        db.session.commit()

        return jsonify({'message': 'Section updated successfully'}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.post('/request_book/<int:book_id>')
@auth_required('token')
@roles_required('user')
@login_required
def request_book(book_id):
    user_id = current_user.user_id
    book = Book.query.get(book_id)

    if not book:
        return jsonify({'message': 'Book not found'}), 404

    # Check if there's already a request for this book by the same user
    existing_request = RequestBook.query.filter_by(user_id=user_id, bid=book_id).first()

    if existing_request:
        return jsonify({'message': 'You have already requested this book'}), 400

    # Check the number of requests the user has made
    request_count = RequestBook.query.filter_by(user_id=user_id).count()

    if request_count >= 5:
        return jsonify({'message': 'You have reached the maximum number of book requests'}), 400

    new_request = RequestBook(
        user_id=user_id,
        bid=book.bid,
        bname=book.bname,
        approved=False,
        return_date=None
    )

    db.session.add(new_request)
    db.session.commit()

    return jsonify({'message': 'Book request recorded'}), 200




@app.post('/revoke_access/<int:request_id>')
@auth_required('token')
@roles_required('librarian')
def revoke_access(request_id):
    request_entry = RequestBook.query.get(request_id)

    if not request_entry:
        return jsonify({'message': 'Request not found'}), 404

    db.session.delete(request_entry)
    db.session.commit()

    return jsonify({'message': 'Access revoked and request deleted'}), 200


@app.get('/user_books')
@auth_required('token')
@roles_required('user')
def user_books():
    user_id = current_user.user_id

    # Fetch all approved requests for the user
    all_requests = RequestBook.query.filter_by(user_id=user_id, approved=True).all()

    # Find and delete overdue requests
    current_time = datetime.utcnow()
    overdue_requests = [r for r in all_requests if r.return_date and r.return_date < current_time]

    for request_entry in overdue_requests:
        db.session.delete(request_entry)

    db.session.commit()

    # Fetch remaining approved requests
    remaining_requests = RequestBook.query.filter_by(user_id=user_id, approved=True).all()

    # Convert the remaining requests to a list of dictionaries for easier JSON serialization
    remaining_requests_list = [
        {
            'request_id': r.request_id,
            'book_id': r.bid,
            'book_name': r.bname,
            'approved': r.approved,
            'return_date': r.return_date
        }
        for r in remaining_requests
    ]

    return jsonify({'remaining_requests': remaining_requests_list}), 200

@app.post('/approve_request/<int:request_id>')
@auth_required('token')
@roles_required('librarian')  # Assuming only librarians can approve requests
def approve_request(request_id):
    # Fetch the request by ID
    request_book = RequestBook.query.get(request_id)

    if not request_book:
        return jsonify({'message': 'Request not found'}), 404

    # Update the request details
    request_book.approved = True
    request_book.return_date = datetime.utcnow() + timedelta(days=7)

    # Commit changes to the database
    db.session.commit()

    return jsonify({'message': 'Book request approved', 'return_date': request_book.return_date}), 200



@app.get('/book_content/<int:book_id>')
@auth_required('token')
@roles_required('user') 
def book_content(book_id):
    book = Book.query.get(book_id)

    if not book:
        return jsonify({'message': 'Book not found'}), 404

    book_data = {
        'id': book.bid,
        'name': book.bname,
        'author': book.author,
        'description': book.description,
        'content': book.content,
        'section_id': book.section_id,
        'rating': book.rating
    }

    return jsonify(book_data), 200



@app.post('/return_book/<int:request_id>')
@auth_required('token')
@roles_required('user')
def return_book(request_id):
    request_entry = RequestBook.query.get(request_id)

    if not request_entry:
        return jsonify({'message': 'Request not found'}), 404

    db.session.delete(request_entry)
    db.session.commit()

    return jsonify({'message': 'Book returned and request deleted'}), 200



@app.post('/like_dislike/<int:book_id>/<int:value>')
@auth_required('token')
@roles_required('user')
def like_dislike(book_id, value):
    user_id = current_user.user_id
    existing_like = Like.query.filter_by(book_id=book_id, user_id=user_id).first()

    if existing_like:
        existing_like.value = value
        db.session.commit()
        return jsonify({'message': 'Like/Dislike updated'}), 200
    else:
        new_like = Like(value=value, book_id=book_id, user_id=user_id)
        db.session.add(new_like)
        db.session.commit()
        return jsonify({'message': 'Like/Dislike added'}), 200



@app.get('/download')
def downloadcsv():
    task = create_resource_csv.delay()  # Trigger the asynchronous task
    return jsonify({'taskid': task.id})

@app.get('/getcsv/<task_id>')
def getcsv(task_id):
    try:
        res = AsyncResult(task_id)  # Get the task result using the task ID

        if res.ready():
            if res.successful():
                filename = res.result  # Get the file path returned by the task

                if filename and os.path.exists(filename):
                    return send_file(filename, as_attachment=True)  # Send the file as a download
                else:
                    return jsonify({'message': 'File not found'}), 404
            else:
                return jsonify({'message': 'Task failed'}), 500
        else:
            return jsonify({'message': 'Task pending'}), 202
    except Exception as e:
        logging.error(f"Error in getcsv route: {e}")
        return jsonify({'message': 'Internal server error'}), 500


