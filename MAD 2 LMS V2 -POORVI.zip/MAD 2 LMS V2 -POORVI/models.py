from flask_sqlalchemy import SQLAlchemy
from flask_security import UserMixin,RoleMixin
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime

db=SQLAlchemy()
class UserRoles(db.Model):
    __tablename__ = 'user_roles'
    user_id = db.Column(db.Integer, db.ForeignKey('user.user_id'), primary_key=True)
    role_id = db.Column(db.Integer, db.ForeignKey('role.id'), primary_key=True)


class User(db.Model, UserMixin):
    user_id = db.Column(db.Integer, primary_key=True)
    user_name = db.Column(db.String(128), nullable=True)
    email = db.Column(db.String(128), unique=True, nullable=False)
    password = db.Column(db.String(128), nullable=False)  # Renamed from password_hash to password
    active = db.Column(db.Boolean, default=True)
    fs_uniquifier = db.Column(db.String(128))
    last_activity = db.Column(db.DateTime, default=datetime.utcnow)
    roles = db.relationship('Role', secondary='user_roles', backref=db.backref('users', lazy=True))
   
    
    def set_password(self, password):
        self.password = generate_password_hash(password)  # Changed password_hash to password

    def check_password(self, password):
        return check_password_hash(self.password, password)  
    
class Section(db.Model):
    sid=db.Column(db.Integer,primary_key=True)
    sname=db.Column(db.String(100),unique=True,nullable=False)
    sdescription=db.Column(db.Text,nullable=False)   
    books=db.relationship('Book',backref='section',lazy=True,cascade='all,delete-orphan')

class Role(db.Model, RoleMixin):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(128), unique=True)
    description = db.Column(db.String(256))

class RequestBook(db.Model):
    __tablename__ = 'request_book'
    request_id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.String, db.ForeignKey('user.user_id'), nullable=False)
    bid = db.Column(db.Integer, db.ForeignKey('book.bid'))
    bname = db.Column(db.String, db.ForeignKey('book.bname'))
    approved = db.Column(db.Boolean, default=False)
    return_date = db.Column(db.DateTime)

class Book(db.Model):
    bid = db.Column(db.Integer, primary_key=True)
    bname = db.Column(db.String(100), nullable=False)
    author = db.Column(db.String(100), nullable=False)  # Added author field
    description = db.Column(db.Text, nullable=False)     # Added description field
    content = db.Column(db.Text, nullable=False)
    section_id = db.Column(db.Integer, db.ForeignKey('section.sid'), nullable=False)
    likes = db.relationship('Like', backref='book', lazy='dynamic')
    rating = db.Column(db.Float, default=1)
    def calculate_rating(self):
        total_likes = Like.query.filter_by(book_id=self.bid, value=True).count()
        total_dislikes = Like.query.filter_by(book_id=self.bid, value=False).count()

        total_votes = total_likes + total_dislikes

        if total_votes == 0:
            return 0

        rating = (total_likes / total_votes) * 100
        return round(rating, 2)

class Like(db.Model):
    __tablename__ = 'like'
    id = db.Column(db.Integer, primary_key=True)
    value = db.Column(db.Integer, nullable=False)
    book_id = db.Column(db.Integer, db.ForeignKey('book.bid'), nullable=False)
    user_id = db.Column(db.String, db.ForeignKey('user.user_id'), nullable=False)
